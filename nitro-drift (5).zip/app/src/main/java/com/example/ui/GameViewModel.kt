package com.example.ui

import android.app.Application
import androidx.compose.runtime.withFrameNanos
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.BackgroundMusicManager
import com.example.audio.HapticsManager
import com.example.audio.SoundFXManager
import com.example.data.db.AppDatabase
import com.example.data.db.CarUnlockEntity
import com.example.data.db.DailyMissionEntity
import com.example.data.db.RaceScoreEntity
import com.example.data.db.UserStatsEntity
import com.example.data.model.CarCatalog
import com.example.data.model.CarPreset
import com.example.data.repository.GameRepository
import com.example.game.GameEngine
import com.example.game.GameEngineState
import com.example.game.GameMode
import com.example.game.GameStatus
import com.example.game.RaceReplaySession
import com.example.game.ReplayFrame
import com.example.game.TrackEnvironment
import com.example.game.WeatherCondition
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class MainUiState(
    val isLoading: Boolean = true,
    val userStats: UserStatsEntity = UserStatsEntity(),
    val carUnlocks: List<CarUnlockEntity> = emptyList(),
    val selectedCar: CarPreset = CarCatalog.defaultCars.first(),
    val selectedCarUnlock: CarUnlockEntity? = null,
    val topScores: List<RaceScoreEntity> = emptyList(),
    val dailyMissions: List<DailyMissionEntity> = emptyList(),
    val selectedMode: GameMode = GameMode.ENDLESS_HIGHWAY,
    val selectedTrack: TrackEnvironment = TrackEnvironment.NEON_CITY,
    val selectedWeather: WeatherCondition = WeatherCondition.NEON_RAIN,
    val soundMuted: Boolean = false,
    val musicMuted: Boolean = false,
    val hapticsMuted: Boolean = false,
    val latestReplay: RaceReplaySession? = null
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = GameRepository(AppDatabase.getDatabase(application))
    val soundFXManager = SoundFXManager(application)
    val musicManager = BackgroundMusicManager(application)
    val hapticsManager = HapticsManager(application)
    private val gameEngine = GameEngine(soundFXManager, hapticsManager)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _gameState = MutableStateFlow(GameEngineState())
    val gameState: StateFlow<GameEngineState> = _gameState.asStateFlow()

    private var gameLoopJob: Job? = null

    // Control inputs
    private var steeringInput = 0f
    private var isAccelerating = false
    private var isBraking = false
    private var isNitroRequested = false

    init {
        musicManager.startMusic(viewModelScope)

        viewModelScope.launch {
            repository.initializeDefaultsIfEmpty()

            combine(
                repository.userStats,
                repository.carUnlocks,
                repository.topScores,
                repository.getDailyMissions(repository.getCurrentDateString()),
                musicManager.isMusicMuted,
                repository.latestReplay
            ) { flows ->
                @Suppress("UNCHECKED_CAST")
                val stats = flows[0] as? UserStatsEntity
                @Suppress("UNCHECKED_CAST")
                val unlocks = (flows[1] as? List<CarUnlockEntity>) ?: emptyList()
                @Suppress("UNCHECKED_CAST")
                val scores = (flows[2] as? List<RaceScoreEntity>) ?: emptyList()
                @Suppress("UNCHECKED_CAST")
                val missions = (flows[3] as? List<DailyMissionEntity>) ?: emptyList()
                val isMusicMuted = (flows[4] as? Boolean) ?: false
                val replay = flows[5] as? RaceReplaySession

                val currentStats = stats ?: UserStatsEntity()
                val currentUnlocks = unlocks.ifEmpty {
                    CarCatalog.defaultCars.map { CarUnlockEntity(carId = it.id, isUnlocked = it.priceCoins == 0) }
                }
                val selCar = CarCatalog.getCarById(currentStats.selectedCarId)
                val selUnlock = currentUnlocks.find { it.carId == selCar.id }

                MainUiState(
                    isLoading = false,
                    userStats = currentStats,
                    carUnlocks = currentUnlocks,
                    selectedCar = selCar,
                    selectedCarUnlock = selUnlock,
                    topScores = scores,
                    dailyMissions = missions,
                    selectedMode = _uiState.value.selectedMode,
                    selectedTrack = _uiState.value.selectedTrack,
                    selectedWeather = _uiState.value.selectedWeather,
                    soundMuted = soundFXManager.isMuted(),
                    musicMuted = isMusicMuted,
                    hapticsMuted = hapticsManager.isMuted(),
                    latestReplay = replay
                )
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    fun setGameMode(mode: GameMode) {
        _uiState.value = _uiState.value.copy(selectedMode = mode)
    }

    fun setTrackEnvironment(track: TrackEnvironment) {
        _uiState.value = _uiState.value.copy(selectedTrack = track)
    }

    fun setWeatherCondition(weather: WeatherCondition) {
        _uiState.value = _uiState.value.copy(selectedWeather = weather)
    }

    fun toggleSoundMute() {
        val newMuted = !soundFXManager.isMuted()
        soundFXManager.setMuted(newMuted)
        _uiState.value = _uiState.value.copy(soundMuted = newMuted)
    }

    fun toggleMusicMute() {
        musicManager.toggleMusicMute()
    }

    fun toggleHapticsMute() {
        val newMuted = hapticsManager.toggleMute()
        _uiState.value = _uiState.value.copy(hapticsMuted = newMuted)
    }

    fun claimDailyMission(missionId: String) {
        viewModelScope.launch {
            val success = repository.claimMissionReward(missionId)
            if (success) {
                soundFXManager.playCoinSound()
            }
        }
    }

    fun getExportableSaveDataJson(): String {
        val state = _uiState.value
        val stats = state.userStats
        val unlockedCars = state.carUnlocks.joinToString(",") { "${it.carId}(Lvl${it.engineLevel},Color:0x${it.paintColorHex.toString(16)})" }
        return """
            {
              "game": "Speed Legend 2026",
              "exportDate": "${System.currentTimeMillis()}",
              "driverLevel": ${stats.driverLevel},
              "driverXp": ${stats.driverXp},
              "coinsBalance": ${stats.coinsBalance},
              "totalRaces": ${stats.totalRaces},
              "totalDistanceMeters": ${stats.totalDistanceMeters},
              "selectedCar": "${state.selectedCar.id}",
              "carUnlocks": "[$unlockedCars]"
            }
        """.trimIndent()
    }

    // Controls input
    fun setSteering(value: Float) {
        steeringInput = value.coerceIn(-1f, 1f)
    }

    fun setAccelerating(accelerating: Boolean) {
        isAccelerating = accelerating
    }

    fun setBraking(braking: Boolean) {
        isBraking = braking
    }

    private val replayFrameBuffer = ArrayDeque<ReplayFrame>()
    private var lastReplaySampleMs = 0L

    fun triggerNitro(active: Boolean) {
        isNitroRequested = active
    }

    fun startRace() {
        gameLoopJob?.cancel()
        replayFrameBuffer.clear()
        lastReplaySampleMs = 0L

        val state = uiState.value
        val initialEngineState = gameEngine.initGame(
            selectedCar = state.selectedCar,
            carUnlock = state.selectedCarUnlock,
            mode = state.selectedMode,
            track = state.selectedTrack,
            weather = state.selectedWeather
        )
        _gameState.value = initialEngineState

        // Countdown coroutine
        viewModelScope.launch {
            for (sec in 3 downTo 1) {
                _gameState.value = _gameState.value.copy(
                    status = GameStatus.COUNTDOWN,
                    countdownSeconds = sec
                )
                soundFXManager.playCoinSound()
                kotlinx.coroutines.delay(800)
            }
            _gameState.value = _gameState.value.copy(status = GameStatus.PLAYING)
            soundFXManager.startEngineSound(viewModelScope)
            runGameLoop()
        }
    }

    private fun runGameLoop() {
        gameLoopJob = viewModelScope.launch {
            var lastFrameTime = System.nanoTime()

            while (_gameState.value.status == GameStatus.PLAYING) {
                withFrameNanos { now ->
                    val deltaSeconds = ((now - lastFrameTime) / 1_000_000_000f).coerceAtMost(0.05f)
                    lastFrameTime = now

                    val updated = gameEngine.update(
                        currentState = _gameState.value,
                        deltaSeconds = deltaSeconds,
                        steeringInput = steeringInput,
                        isAccelerating = isAccelerating,
                        isBraking = isBraking,
                        isNitroRequested = isNitroRequested
                    )

                    _gameState.value = updated

                    // Replay Frame Sampling (30fps / 33ms interval)
                    val nowMs = System.currentTimeMillis()
                    if (nowMs - lastReplaySampleMs >= 33) {
                        lastReplaySampleMs = nowMs
                        val frame = ReplayFrame(
                            frameTimeMs = nowMs,
                            playerXNorm = updated.playerXNorm,
                            speedMph = updated.speedMph,
                            roadOffsetNormalized = updated.roadOffsetNormalized,
                            score = updated.score,
                            coinsCollected = updated.coinsCollected,
                            health = updated.health,
                            isNitroActive = updated.isNitroActive,
                            hasShield = updated.hasShield,
                            closeCallAlert = updated.closeCallAlert,
                            objects = updated.objects,
                            particles = updated.particles
                        )
                        replayFrameBuffer.addLast(frame)
                        if (replayFrameBuffer.size > 900) { // Max 30 seconds of frames
                            replayFrameBuffer.removeFirst()
                        }
                    }

                    if (updated.status == GameStatus.GAME_OVER) {
                        soundFXManager.stopEngineSound()
                        finalizeReplayRecording(updated)
                        onGameOver(updated)
                    }
                }
            }
        }
    }

    private fun finalizeReplayRecording(finalState: GameEngineState) {
        if (replayFrameBuffer.isEmpty()) return
        val frames = replayFrameBuffer.toList()
        val durationSec = ((frames.last().frameTimeMs - frames.first().frameTimeMs) / 1000f).coerceAtLeast(1f)
        val state = uiState.value
        val session = RaceReplaySession(
            id = "replay_${System.currentTimeMillis()}",
            timestamp = System.currentTimeMillis(),
            durationSeconds = durationSec,
            carId = state.selectedCar.id,
            carPaintHex = state.selectedCarUnlock?.paintColorHex ?: state.selectedCar.primaryColorHex,
            track = state.selectedTrack,
            weather = state.selectedWeather,
            mode = state.selectedMode,
            finalScore = finalState.score,
            maxSpeedMph = finalState.maxSpeedMph.toInt(),
            frames = frames
        )
        repository.saveReplaySession(session)
    }

    fun pauseGame() {
        if (_gameState.value.status == GameStatus.PLAYING) {
            _gameState.value = _gameState.value.copy(status = GameStatus.PAUSED)
            soundFXManager.stopEngineSound()
        }
    }

    fun resumeGame() {
        if (_gameState.value.status == GameStatus.PAUSED) {
            _gameState.value = _gameState.value.copy(status = GameStatus.PLAYING)
            soundFXManager.startEngineSound(viewModelScope)
            runGameLoop()
        }
    }

    fun quitRace() {
        gameLoopJob?.cancel()
        soundFXManager.stopEngineSound()
        if (_gameState.value.status == GameStatus.PLAYING) {
            finalizeReplayRecording(_gameState.value)
        }
        _gameState.value = _gameState.value.copy(status = GameStatus.IDLE)
    }

    private fun onGameOver(finalState: GameEngineState) {
        viewModelScope.launch {
            repository.recordRaceResult(
                score = finalState.score,
                distanceMeters = finalState.distanceMeters,
                maxSpeedMph = finalState.maxSpeedMph.toInt(),
                coinsEarned = finalState.coinsCollected,
                closeCalls = finalState.closeCalls,
                trackName = finalState.track.displayName,
                gameMode = finalState.mode.displayName
            )
        }
    }

    // Garage Actions
    fun selectCar(carId: String) {
        viewModelScope.launch {
            repository.setSelectedCar(carId)
        }
    }

    fun unlockCar(carId: String, price: Int) {
        viewModelScope.launch {
            val success = repository.unlockCar(carId, price)
            if (success) {
                soundFXManager.playNitroSound()
                selectCar(carId)
            } else {
                soundFXManager.playCrashSound()
            }
        }
    }

    fun updateCarPaint(carId: String, colorHex: Long) {
        viewModelScope.launch {
            repository.updateCarPaint(carId, colorHex)
            soundFXManager.playCoinSound()
        }
    }

    fun upgradeCarPart(carId: String, partType: String, cost: Int) {
        viewModelScope.launch {
            val success = repository.upgradeCarPart(carId, partType, cost)
            if (success) {
                soundFXManager.playNitroSound()
            } else {
                soundFXManager.playCrashSound()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundFXManager.release()
        musicManager.stopMusic()
    }
}
