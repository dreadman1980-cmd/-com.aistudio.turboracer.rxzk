package com.example.ui.screens

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.PedalBike
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.ui.components.ReplayPlayerDialog
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.CarPreset
import com.example.game.EntityType
import com.example.game.GameEngineState
import com.example.game.GameStatus
import com.example.game.WeatherCondition
import com.example.ui.GameViewModel
import com.example.ui.components.GameOverOverlay
import com.example.ui.components.NitroMeterButton
import com.example.ui.components.PauseOverlay
import com.example.ui.components.RadarMinimap
import com.example.ui.components.SpeedometerGauge
import com.example.ui.components.TopHUDBar
import com.example.ui.theme.RacingCyan
import com.example.ui.theme.RacingGold
import com.example.ui.theme.RacingGreen
import com.example.ui.theme.RacingRed

@Composable
fun RacingScreen(
    viewModel: GameViewModel,
    onExitToGarage: () -> Unit
) {
    val gameState by viewModel.gameState.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    // Touch steer state
    val touchSteerInput = remember { mutableFloatStateOf(0f) }

    // Accelerometer tilt steering integration
    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event != null && gameState.status == GameStatus.PLAYING) {
                    val tiltX = event.values[0] // tilt left/right in portrait
                    // if user tilts phone right, values[0] becomes negative
                    val targetSteer = (-tiltX / 4.0f).coerceIn(-1.0f, 1.0f)
                    if (kotlin.math.abs(targetSteer) > 0.05f) {
                        viewModel.setSteering(targetSteer)
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        if (accelerometer != null) {
            sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        }

        onDispose {
            sensorManager?.unregisterListener(listener)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val screenWidth = size.width
                        val normalizedX = (offset.x / screenWidth.toFloat()) * 2f - 1f
                        touchSteerInput.floatValue = normalizedX
                        viewModel.setSteering(normalizedX)
                    },
                    onDragEnd = {
                        touchSteerInput.floatValue = 0f
                        viewModel.setSteering(0f)
                    },
                    onDragCancel = {
                        touchSteerInput.floatValue = 0f
                        viewModel.setSteering(0f)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val current = touchSteerInput.floatValue
                        val updated = (current + dragAmount.x / 300f).coerceIn(-1f, 1f)
                        touchSteerInput.floatValue = updated
                        viewModel.setSteering(updated)
                    }
                )
            }
    ) {
        // 1. 2D Interactive Track Canvas
        RacingCanvas(
            state = gameState,
            selectedCar = uiState.selectedCar,
            carPaintHex = uiState.selectedCarUnlock?.paintColorHex ?: uiState.selectedCar.primaryColorHex,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Top HUD Bar
        TopHUDBar(
            state = gameState,
            onPauseClick = { viewModel.pauseGame() },
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // 3. Countdown overlay
        if (gameState.status == GameStatus.COUNTDOWN) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${gameState.countdownSeconds}",
                    color = RacingRed,
                    fontWeight = FontWeight.Black,
                    fontSize = 90.sp
                )
            }
        }

        // 4. On-Screen Touch Controls Overlay
        if (gameState.status == GameStatus.PLAYING) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                // Left & Right Steering Touch Buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val leftInteraction = remember { MutableInteractionSource() }
                    val isLeftPressed by leftInteraction.collectIsPressedAsState()

                    val rightInteraction = remember { MutableInteractionSource() }
                    val isRightPressed by rightInteraction.collectIsPressedAsState()

                    LaunchedEffect(isLeftPressed, isRightPressed) {
                        when {
                            isLeftPressed -> viewModel.setSteering(-1f)
                            isRightPressed -> viewModel.setSteering(1f)
                            else -> viewModel.setSteering(0f)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color(0xCC1E293B))
                            .border(2.dp, RacingCyan, CircleShape)
                            .clickable(
                                interactionSource = leftInteraction,
                                indication = null
                            ) { }
                            .testTag("steer_left_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Steer Left",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color(0xCC1E293B))
                            .border(2.dp, RacingCyan, CircleShape)
                            .clickable(
                                interactionSource = rightInteraction,
                                indication = null
                            ) { }
                            .testTag("steer_right_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Steer Right",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                // Center: Speedometer Gauge & Radar Minimap
                Row(verticalAlignment = Alignment.Bottom) {
                    SpeedometerGauge(
                        speedMph = gameState.speedMph,
                        maxSpeedMph = gameState.maxSpeedMph,
                        gear = gameState.gear,
                        rpmRatio = gameState.rpmRatio
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    RadarMinimap(state = gameState)
                }

                // Right: Accelerator Gas & Nitro Boost
                Column(horizontalAlignment = Alignment.End) {
                    // Nitro Button
                    val nitroInteraction = remember { MutableInteractionSource() }
                    val isNitroPressed by nitroInteraction.collectIsPressedAsState()

                    LaunchedEffect(isNitroPressed) {
                        viewModel.triggerNitro(isNitroPressed)
                    }

                    NitroMeterButton(
                        nitroLevel = gameState.nitroLevel,
                        isNitroActive = gameState.isNitroActive,
                        onNitroPress = { viewModel.triggerNitro(it) }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Gas / Accelerator Pedal Button
                    val gasInteraction = remember { MutableInteractionSource() }
                    val isGasPressed by gasInteraction.collectIsPressedAsState()

                    LaunchedEffect(isGasPressed) {
                        viewModel.setAccelerating(isGasPressed)
                    }

                    Box(
                        modifier = Modifier
                            .size(72.dp, 80.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isGasPressed) RacingRed else Color(0xCC1E293B)
                            )
                            .border(2.dp, RacingRed, RoundedCornerShape(16.dp))
                            .clickable(
                                interactionSource = gasInteraction,
                                indication = null
                            ) { }
                            .testTag("gas_pedal_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = "Gas Pedal",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                            Text(
                                text = "GAS",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // 5. Overlays
        if (gameState.status == GameStatus.PAUSED) {
            PauseOverlay(
                onResume = { viewModel.resumeGame() },
                onQuit = {
                    viewModel.quitRace()
                    onExitToGarage()
                },
                onToggleSound = { viewModel.toggleSoundMute() },
                isMuted = uiState.soundMuted,
                onToggleMusic = { viewModel.toggleMusicMute() },
                isMusicMuted = uiState.musicMuted
            )
        }

        var showGameOverReplay by remember { mutableStateOf(false) }

        if (showGameOverReplay && uiState.latestReplay != null) {
            ReplayPlayerDialog(
                session = uiState.latestReplay!!,
                onDismiss = { showGameOverReplay = false }
            )
        }

        if (gameState.status == GameStatus.GAME_OVER) {
            GameOverOverlay(
                finalState = gameState,
                onPlayAgain = { viewModel.startRace() },
                onWatchReplay = if (uiState.latestReplay != null) { { showGameOverReplay = true } } else null,
                onMenu = {
                    viewModel.quitRace()
                    onExitToGarage()
                }
            )
        }
    }
}

@Composable
fun RacingCanvas(
    state: GameEngineState,
    selectedCar: CarPreset,
    carPaintHex: Long,
    modifier: Modifier = Modifier
) {
    val carApexBitmap = ImageBitmap.imageResource(id = R.drawable.img_car_apex_1785168558962)
    val carCyberBitmap = ImageBitmap.imageResource(id = R.drawable.img_car_cyber_1785168571821)
    val carMuscleBitmap = ImageBitmap.imageResource(id = R.drawable.img_car_muscle_1785168581880)

    val playerCarBitmap = when (selectedCar.id) {
        "car_cyber" -> carCyberBitmap
        "car_muscle" -> carMuscleBitmap
        else -> carApexBitmap
    }

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        // 1. Draw Horizon & Background Sky Gradient
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(state.track.bgGradientStart),
                    Color(state.track.bgGradientEnd)
                )
            ),
            size = Size(width, height)
        )

        // 2. Draw Road Asphalt & Borders
        val roadLeft = width * 0.10f
        val roadRight = width * 0.90f
        val roadWidth = roadRight - roadLeft

        // Grass/Desert Outer Margins
        drawRect(
            color = Color(state.track.asphaltColor),
            topLeft = Offset(roadLeft, 0f),
            size = Size(roadWidth, height)
        )

        // Road Outer Border Lines (Glow)
        drawLine(
            color = Color(state.track.borderLineColor),
            start = Offset(roadLeft, 0f),
            end = Offset(roadLeft, height),
            strokeWidth = 10f
        )
        drawLine(
            color = Color(state.track.borderLineColor),
            start = Offset(roadRight, 0f),
            end = Offset(roadRight, height),
            strokeWidth = 10f
        )

        // 3. Draw Moving Dash Lane Divider Lines
        val numLanes = 4
        val laneWidth = roadWidth / numLanes
        val dashLength = 40f
        val gapLength = 30f
        val totalDashCycle = dashLength + gapLength
        val scrollPixels = state.roadOffsetNormalized * totalDashCycle * 8f

        for (laneIdx in 1 until numLanes) {
            val laneX = roadLeft + laneIdx * laneWidth
            var currentY = -totalDashCycle + (scrollPixels % totalDashCycle)

            while (currentY < height) {
                drawLine(
                    color = Color.White.copy(alpha = 0.6f),
                    start = Offset(laneX, currentY),
                    end = Offset(laneX, currentY + dashLength),
                    strokeWidth = 6f
                )
                currentY += totalDashCycle
            }
        }

        // 4. Draw Game Objects (Traffic Cars, Coins, Powerups)
        for (obj in state.objects) {
            val objX = roadLeft + ((obj.xNormalized + 0.8f) / 1.6f) * roadWidth
            val objY = obj.yNormalized * height
            val objW = obj.widthNormalized * roadWidth
            val objH = obj.heightNormalized * height

            when (obj.type) {
                EntityType.COIN -> {
                    drawCircle(
                        color = RacingGold,
                        radius = objW / 2f,
                        center = Offset(objX, objY)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = objW / 4f,
                        center = Offset(objX, objY)
                    )
                }
                EntityType.POWERUP_NITRO -> {
                    drawRoundRect(
                        color = RacingCyan,
                        topLeft = Offset(objX - objW / 2f, objY - objH / 2f),
                        size = Size(objW, objH),
                        cornerRadius = CornerRadius(12f)
                    )
                }
                EntityType.POWERUP_SHIELD -> {
                    drawCircle(
                        color = RacingGreen,
                        radius = objW / 2f,
                        center = Offset(objX, objY)
                    )
                }
                EntityType.POWERUP_REPAIR -> {
                    drawRoundRect(
                        color = Color(0xFF22C55E),
                        topLeft = Offset(objX - objW / 2f, objY - objH / 2f),
                        size = Size(objW, objH),
                        cornerRadius = CornerRadius(8f)
                    )
                }
                EntityType.POWERUP_MAGNET -> {
                    drawCircle(
                        color = Color(0xFFA855F7),
                        radius = objW / 2f,
                        center = Offset(objX, objY)
                    )
                }
                else -> {
                    // Draw Traffic Cars
                    drawRoundRect(
                        color = Color(obj.colorHex),
                        topLeft = Offset(objX - objW / 2f, objY - objH / 2f),
                        size = Size(objW, objH),
                        cornerRadius = CornerRadius(16f)
                    )
                    // Headlights
                    drawCircle(color = Color.Yellow, radius = 4f, center = Offset(objX - objW / 3f, objY + objH / 2f))
                    drawCircle(color = Color.Yellow, radius = 4f, center = Offset(objX + objW / 3f, objY + objH / 2f))
                    // Windshield
                    drawRect(
                        color = Color.DarkGray,
                        topLeft = Offset(objX - objW / 3f, objY - objH / 4f),
                        size = Size(objW * 0.66f, objH / 3f)
                    )
                }
            }
        }

        // 5. Draw Particle Effects (Exhaust smoke, Nitro flames, Sparkles)
        for (p in state.particles) {
            val px = roadLeft + ((p.xNorm + 0.8f) / 1.6f) * roadWidth
            val py = p.yNorm * height
            drawCircle(
                color = Color(p.colorHex).copy(alpha = p.alpha),
                radius = p.radius,
                center = Offset(px, py)
            )
        }

        // 6. Draw Player Car
        val playerPx = roadLeft + ((state.playerXNorm + 0.8f) / 1.6f) * roadWidth
        val playerPy = 0.80f * height
        val playerW = 0.22f * roadWidth
        val playerH = 0.18f * height

        // Shield aura glow
        if (state.hasShield) {
            drawCircle(
                color = RacingCyan.copy(alpha = 0.4f),
                radius = playerW * 0.9f,
                center = Offset(playerPx, playerPy)
            )
            drawCircle(
                color = RacingCyan,
                radius = playerW * 0.85f,
                center = Offset(playerPx, playerPy),
                style = Stroke(width = 6f)
            )
        }

        // Draw Player Car Sprite image bitmap
        drawImage(
            image = playerCarBitmap,
            dstOffset = IntOffset((playerPx - playerW / 2f).toInt(), (playerPy - playerH / 2f).toInt()),
            dstSize = IntSize(playerW.toInt(), playerH.toInt())
        )

        // Headlight beams
        drawArc(
            color = Color.Yellow.copy(alpha = 0.25f),
            startAngle = 230f,
            sweepAngle = 80f,
            useCenter = true,
            topLeft = Offset(playerPx - playerW, playerPy - playerH * 2f),
            size = Size(playerW * 2f, playerH * 2f)
        )

        // 7. Draw Weather Particle System & Atmospheric Visibility Overlay
        when (state.weather) {
            WeatherCondition.NEON_RAIN -> {
                // Rain streaks & splash ripples
                for (wp in state.weatherParticles) {
                    val px = wp.xNorm * width
                    val py = wp.yNorm * height
                    val endX = px + wp.speedX * width * 0.12f
                    val endY = py + wp.length

                    drawLine(
                        color = Color(wp.colorHex).copy(alpha = wp.alpha),
                        start = Offset(px, py),
                        end = Offset(endX, endY),
                        strokeWidth = wp.radius * 1.5f,
                        cap = StrokeCap.Round
                    )

                    // Wet asphalt splash ripples near road bottom
                    if (wp.yNorm > 0.65f) {
                        drawOval(
                            color = Color(wp.colorHex).copy(alpha = wp.alpha * 0.4f),
                            topLeft = Offset(px - 10f, py + wp.length - 2f),
                            size = Size(20f, 6f),
                            style = Stroke(width = 1.5f)
                        )
                    }
                }

                // Rain Atmospheric Fog / Reduced Visibility Haze at Horizon
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0x990A1526), // Translucent cyan rain mist
                            Color(0x330A1526),
                            Color.Transparent
                        )
                    ),
                    topLeft = Offset(0f, 0f),
                    size = Size(width, height * 0.45f)
                )
            }
            WeatherCondition.CYBER_SNOW -> {
                // Cyber Snowflakes
                for (wp in state.weatherParticles) {
                    val px = wp.xNorm * width
                    val py = wp.yNorm * height

                    // Outer soft glow
                    drawCircle(
                        color = Color(wp.colorHex).copy(alpha = wp.alpha * 0.35f),
                        radius = wp.radius * 2.2f,
                        center = Offset(px, py)
                    )
                    // Inner flake
                    drawCircle(
                        color = Color.White.copy(alpha = wp.alpha),
                        radius = wp.radius,
                        center = Offset(px, py)
                    )
                }

                // Frost Vignette & Atmospheric Fog Haze
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0x15E0F7FA),
                            Color(0x55091D2E)
                        ),
                        center = Offset(width / 2f, height / 2f),
                        radius = width.coerceAtLeast(height) * 0.7f
                    ),
                    size = Size(width, height)
                )

                // Horizon Snow Blurring Fog Layer
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0x88091D2E),
                            Color(0x22091D2E),
                            Color.Transparent
                        )
                    ),
                    topLeft = Offset(0f, 0f),
                    size = Size(width, height * 0.40f)
                )
            }
            WeatherCondition.CLEAR -> {
                // Clear sky - full optimal visibility
            }
        }
    }
}
