package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RacingRed = Color(0xFFFF2A55)
val RacingCyan = Color(0xFF00F0FF)
val RacingGold = Color(0xFFFFD700)
val RacingGreen = Color(0xFF00E676)
val DarkCanvas = Color(0xFF0A0D14)
val DarkSurface = Color(0xFF141923)
val DarkSurfaceVariant = Color(0xFF1E2536)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)

