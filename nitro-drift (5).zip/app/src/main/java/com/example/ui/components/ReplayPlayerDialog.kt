package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CarCatalog
import com.example.game.GameEngineState
import com.example.game.GameStatus
import com.example.game.RaceReplaySession
import com.example.ui.screens.RacingCanvas
import com.example.ui.theme.DarkCanvas
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.RacingCyan
import com.example.ui.theme.RacingGold
import com.example.ui.theme.RacingGreen
import com.example.ui.theme.RacingRed
import kotlinx.coroutines.delay

@Composable
fun ReplayPlayerDialog(
    session: RaceReplaySession,
    onDismiss: () -> Unit
) {
    if (session.frames.isEmpty()) {
        onDismiss()
        return
    }

    var currentFrameIdx by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(true) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) } // 0.5x, 1.0x, 2.0x

    val totalFrames = session.frames.size
    val currentFrame = session.frames[currentFrameIdx.coerceIn(0, totalFrames - 1)]

    // Auto playback loop
    LaunchedEffect(isPlaying, playbackSpeed, currentFrameIdx) {
        if (isPlaying) {
            val frameDelayMs = (33f / playbackSpeed).toLong().coerceAtLeast(10L)
            delay(frameDelayMs)
            if (currentFrameIdx < totalFrames - 1) {
                currentFrameIdx++
            } else {
                currentFrameIdx = 0 // Loop back
            }
        }
    }

    val carPreset = CarCatalog.defaultCars.find { it.id == session.carId } ?: CarCatalog.defaultCars.first()

    // Build synthesized GameEngineState for frame rendering
    val engineState = GameEngineState(
        status = GameStatus.PLAYING,
        mode = session.mode,
        track = session.track,
        weather = session.weather,
        playerXNorm = currentFrame.playerXNorm,
        speedMph = currentFrame.speedMph,
        maxSpeedMph = session.maxSpeedMph.toFloat(),
        roadOffsetNormalized = currentFrame.roadOffsetNormalized,
        score = currentFrame.score,
        coinsCollected = currentFrame.coinsCollected,
        health = currentFrame.health,
        isNitroActive = currentFrame.isNitroActive,
        hasShield = currentFrame.hasShield,
        closeCallAlert = currentFrame.closeCallAlert,
        objects = currentFrame.objects,
        particles = currentFrame.particles
    )

    val currentSeconds = ((currentFrameIdx.toFloat() / totalFrames) * session.durationSeconds).toInt()
    val totalSeconds = session.durationSeconds.toInt()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkCanvas)
        ) {
            // 1. Full Screen Racing Canvas Replay Playback
            RacingCanvas(
                state = engineState,
                selectedCar = carPreset,
                carPaintHex = session.carPaintHex,
                modifier = Modifier.fillMaxSize()
            )

            // 2. Camera Frame Viewfinder Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .border(2.dp, RacingCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            )

            // 3. Top Replay Header Banner
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // REC / REPLAY Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(20.dp))
                            .border(1.dp, RacingRed, RoundedCornerShape(20.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(RacingRed)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "INSTANT REPLAY (30S)",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }

                    // Close Button
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.7f), CircleShape)
                            .testTag("close_replay_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Replay",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Info Chips
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${session.track.displayName} • ${session.mode.displayName}",
                        color = RacingCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // 4. Live Stats Overlay (Middle Right)
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 80.dp, end = 20.dp),
                horizontalAlignment = Alignment.End
            ) {
                // Speed Chip
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(12.dp))
                        .border(1.dp, RacingCyan, RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = RacingCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("${currentFrame.speedMph.toInt()} MPH", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Score Chip
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(12.dp))
                        .border(1.dp, RacingGold, RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(imageVector = Icons.Default.MonetizationOn, contentDescription = null, tint = RacingGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("${currentFrame.score} PTS", color = RacingGold, fontWeight = FontWeight.Black, fontSize = 13.sp)
                }

                // Close call alert popup
                if (currentFrame.closeCallAlert != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = currentFrame.closeCallAlert,
                        color = RacingGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                            .border(1.dp, RacingGreen, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            // 5. Bottom Replay Control Dock
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.92f)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Scrubber Bar & Timestamps
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = String.format("%02d:%02d", currentSeconds / 60, currentSeconds % 60),
                            color = RacingCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )

                        Text(
                            text = "30s RACE REPLAY TIMELINE",
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )

                        Text(
                            text = String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Slider(
                        value = currentFrameIdx.toFloat(),
                        onValueChange = {
                            currentFrameIdx = it.toInt().coerceIn(0, totalFrames - 1)
                        },
                        valueRange = 0f..(totalFrames - 1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = RacingCyan,
                            activeTrackColor = RacingCyan,
                            inactiveTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("replay_timeline_slider")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Buttons Row (Play/Pause, Speeds)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Play/Pause Button
                        Button(
                            onClick = { isPlaying = !isPlaying },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlaying) RacingRed else RacingGreen
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("replay_play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isPlaying) "PAUSE" else "PLAY",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        // Playback Speed Options
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "SPEED:", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(6.dp))

                            listOf(0.5f, 1.0f, 2.0f).forEach { speed ->
                                val isSelected = (playbackSpeed == speed)
                                val speedLabel = when (speed) {
                                    0.5f -> "0.5x"
                                    1.0f -> "1.0x"
                                    else -> "2.0x"
                                }

                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 3.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) RacingCyan else Color(0xFF1E293B))
                                        .clickable { playbackSpeed = speed }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                        .testTag("speed_${speedLabel}")
                                ) {
                                    Text(
                                        text = speedLabel,
                                        color = if (isSelected) Color.Black else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
