package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameEngineState
import com.example.game.GameMode
import com.example.game.WeatherCondition
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.RacingCyan
import com.example.ui.theme.RacingGold
import com.example.ui.theme.RacingGreen
import com.example.ui.theme.RacingRed
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun TopHUDBar(
    state: GameEngineState,
    onPauseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Health & Shield
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .background(Color(0xCC0D131F), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFF2E384D), RoundedCornerShape(16.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = if (state.hasShield) Icons.Default.Shield else Icons.Default.DirectionsCar,
                contentDescription = "Health Icon",
                tint = if (state.hasShield) RacingCyan else RacingRed,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${state.health}%",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    if (state.hasShield) {
                        Text(
                            text = " (SHIELD)",
                            color = RacingCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .width(70.dp)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFF1E293B))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(state.health / 100f)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (state.health > 40) RacingGreen else RacingRed)
                    )
                }
            }
        }

        // Center: Distance / Score & Coins
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .background(Color(0xCC0D131F), RoundedCornerShape(16.dp))
                .border(1.dp, RacingGold.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.MonetizationOn,
                contentDescription = "Coins",
                tint = RacingGold,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "${state.coinsCollected}",
                color = RacingGold,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "${state.score} PTS",
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp
            )
            if (state.comboMultiplier > 1) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .background(RacingGold, RoundedCornerShape(8.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "x${state.comboMultiplier}",
                        color = Color.Black,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 10.sp
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = when (state.weather) {
                    WeatherCondition.CLEAR -> "☀️"
                    WeatherCondition.NEON_RAIN -> "🌧️"
                    WeatherCondition.CYBER_SNOW -> "❄️"
                },
                fontSize = 13.sp
            )
        }

        // Right: Time / Pause
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (state.mode == GameMode.TIME_TRIAL) {
                Box(
                    modifier = Modifier
                        .background(Color(0xCC0D131F), RoundedCornerShape(16.dp))
                        .border(1.dp, RacingRed, RoundedCornerShape(16.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = "Timer",
                            tint = RacingRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${state.timeRemainingSeconds.toInt()}s",
                            color = RacingRed,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            IconButton(
                onClick = onPauseClick,
                modifier = Modifier
                    .size(36.dp)
                    .background(Color(0xCC0D131F), CircleShape)
                    .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                    .testTag("pause_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Pause,
                    contentDescription = "Pause Game",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun SpeedometerGauge(
    speedMph: Float,
    maxSpeedMph: Float,
    gear: Int,
    rpmRatio: Float,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(110.dp)
            .background(Color(0xDD0A0D14), CircleShape)
            .border(2.dp, Brush.sweepGradient(listOf(RacingCyan, RacingRed, RacingCyan)), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.width / 2f

            // Gauge background arc
            drawArc(
                color = Color(0xFF1E293B),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(width = 10f, cap = StrokeCap.Round)
            )

            // Speed filled arc
            val sweep = (speedMph / (maxSpeedMph * 1.3f)).coerceIn(0f, 1f) * 270f
            drawArc(
                brush = Brush.sweepGradient(listOf(RacingCyan, RacingGold, RacingRed)),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                style = Stroke(width = 10f, cap = StrokeCap.Round)
            )

            // Needle
            val needleAngle = Math.toRadians((135f + sweep).toDouble())
            val needleEnd = Offset(
                center.x + (radius - 16f) * cos(needleAngle).toFloat(),
                center.y + (radius - 16f) * sin(needleAngle).toFloat()
            )
            drawLine(
                color = RacingRed,
                start = center,
                end = needleEnd,
                strokeWidth = 5f,
                cap = StrokeCap.Round
            )
            drawCircle(color = Color.White, radius = 6f, center = center)
        }

        // Digital readout
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text(
                text = "${speedMph.toInt()}",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 22.sp
            )
            Text(
                text = "MPH",
                color = RacingCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
            )
            Text(
                text = "GEAR $gear",
                color = RacingGold,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun NitroMeterButton(
    nitroLevel: Float,
    isNitroActive: Boolean,
    onNitroPress: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .size(72.dp)
            .shadow(12.dp, CircleShape)
            .clip(CircleShape)
            .background(
                if (isNitroActive) Brush.radialGradient(listOf(RacingCyan, Color(0xFF00363A)))
                else Brush.verticalGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
            )
            .border(
                2.dp,
                if (nitroLevel > 20f) RacingCyan else Color.Gray,
                CircleShape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) { }
            .testTag("nitro_button"),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = "Nitro Boost",
                tint = if (isNitroActive) Color.White else RacingCyan,
                modifier = Modifier.size(28.dp)
            )
            Text(
                text = "NITRO",
                color = if (isNitroActive) Color.White else RacingCyan,
                fontWeight = FontWeight.Black,
                fontSize = 9.sp
            )
            Text(
                text = "${nitroLevel.toInt()}%",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 8.sp
            )
        }
    }
}

@Composable
fun RadarMinimap(
    state: GameEngineState,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(70.dp, 100.dp)
            .background(Color(0xDD0A0D14), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF2E384D), RoundedCornerShape(12.dp))
            .padding(4.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Lanes
            for (i in 1..3) {
                val lx = w * (i / 4f)
                drawLine(
                    color = Color(0xFF2A364F),
                    start = Offset(lx, 0f),
                    end = Offset(lx, h),
                    strokeWidth = 1f
                )
            }

            // Player dot
            val playerPx = (state.playerXNorm + 0.8f) / 1.6f * w
            drawCircle(
                color = RacingCyan,
                radius = 4f,
                center = Offset(playerPx, h * 0.8f)
            )

            // Objects
            for (obj in state.objects) {
                val ox = (obj.xNormalized + 0.8f) / 1.6f * w
                val oy = obj.yNormalized * h
                val color = when {
                    obj.colorHex == 0xFFFFD700 -> RacingGold
                    obj.colorHex == 0xFF00F0FF -> RacingCyan
                    else -> RacingRed
                }
                drawCircle(color = color, radius = 3f, center = Offset(ox, oy))
            }
        }
    }
}

@Composable
fun PauseOverlay(
    onResume: () -> Unit,
    onQuit: () -> Unit,
    onToggleSound: () -> Unit,
    isMuted: Boolean,
    onToggleMusic: () -> Unit,
    isMusicMuted: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.8f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .width(320.dp)
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "PAUSED",
                    color = RacingCyan,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp
                )
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onResume,
                    colors = ButtonDefaults.buttonColors(containerColor = RacingRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("resume_button")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("RESUME RACE", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Sound Effects Toggle
                Button(
                    onClick = onToggleSound,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isMuted) "SOUND FX: MUTED" else "SOUND FX: ON", color = Color.White)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Background Music Toggle
                Button(
                    onClick = onToggleMusic,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("music_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isMusicMuted) Icons.Default.MusicOff else Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = if (isMusicMuted) Color.Gray else RacingCyan
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isMusicMuted) "MUSIC: MUTED" else "MUSIC: PLAYING",
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onQuit,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("EXIT TO GARAGE", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun GameOverOverlay(
    finalState: GameEngineState,
    onPlayAgain: () -> Unit,
    onWatchReplay: (() -> Unit)? = null,
    onMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .width(320.dp)
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "RACE FINISHED",
                    color = RacingRed,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp
                )
                Text(
                    text = finalState.closeCallAlert ?: "GREAT RUN!",
                    color = RacingCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Stats Summary Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TOTAL SCORE", color = Color.Gray, fontSize = 12.sp)
                            Text("${finalState.score} PTS", color = RacingGold, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("DISTANCE", color = Color.Gray, fontSize = 12.sp)
                            Text("${finalState.distanceMeters.toInt()}m", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("COINS EARNED", color = Color.Gray, fontSize = 12.sp)
                            Text("+${finalState.coinsCollected}", color = RacingGold, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("CLOSE OVERTAKES", color = Color.Gray, fontSize = 12.sp)
                            Text("${finalState.closeCalls}", color = RacingCyan, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                if (onWatchReplay != null) {
                    Button(
                        onClick = onWatchReplay,
                        colors = ButtonDefaults.buttonColors(containerColor = RacingCyan),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("game_over_watch_replay_button")
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("WATCH 30s REPLAY", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }

                Button(
                    onClick = onPlayAgain,
                    colors = ButtonDefaults.buttonColors(containerColor = RacingRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("play_again_button")
                ) {
                    Text("PLAY AGAIN", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onMenu,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("MAIN GARAGE", color = Color.White)
                }
            }
        }
    }
}
