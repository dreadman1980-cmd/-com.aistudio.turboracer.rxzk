package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Videocam
import com.example.ui.components.ReplayPlayerDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CarCatalog
import com.example.data.model.CarPreset
import com.example.ui.GameViewModel
import com.example.ui.theme.DarkCanvas
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.RacingCyan
import com.example.ui.theme.RacingGold
import com.example.ui.theme.RacingGreen
import com.example.ui.theme.RacingRed

@Composable
fun GarageScreen(
    viewModel: GameViewModel,
    onBackToMain: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTabCar by remember(uiState.selectedCar) { mutableStateOf(uiState.selectedCar) }

    val currentUnlock = uiState.carUnlocks.find { it.carId == selectedTabCar.id }
    val isUnlocked = currentUnlock?.isUnlocked ?: (selectedTabCar.priceCoins == 0)

    var showReplayDialog by remember { mutableStateOf(false) }

    if (showReplayDialog && uiState.latestReplay != null) {
        ReplayPlayerDialog(
            session = uiState.latestReplay!!,
            onDismiss = { showReplayDialog = false }
        )
    }

    Scaffold(
        containerColor = DarkCanvas,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackToMain,
                    modifier = Modifier.testTag("garage_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Text(
                    text = "THE GARAGE",
                    color = RacingCyan,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Coin Balance Chip
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(Color(0xFF1E293B), RoundedCornerShape(16.dp))
                            .border(1.dp, RacingGold, RoundedCornerShape(16.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Coins",
                            tint = RacingGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${uiState.userStats.coinsBalance}",
                            color = RacingGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = { viewModel.toggleMusicMute() },
                        modifier = Modifier.testTag("garage_music_toggle")
                    ) {
                        Icon(
                            imageVector = if (uiState.musicMuted) Icons.Default.MusicOff else Icons.Default.MusicNote,
                            contentDescription = "Music Toggle",
                            tint = if (uiState.musicMuted) Color.Gray else RacingCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // 1. Car Selection Carousel
            Text(
                text = "SELECT VEHICLE",
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(CarCatalog.defaultCars) { car ->
                    val carUnlock = uiState.carUnlocks.find { it.carId == car.id }
                    val unlocked = carUnlock?.isUnlocked ?: (car.priceCoins == 0)
                    val isSelected = (selectedTabCar.id == car.id)

                    Card(
                        modifier = Modifier
                            .width(180.dp)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) RacingCyan else Color(0xFF2E384D),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                selectedTabCar = car
                                if (unlocked) {
                                    viewModel.selectCar(car.id)
                                }
                            }
                            .testTag("garage_car_card_${car.id}"),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(90.dp)
                                    .background(Color(0xFF0F172A), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = car.imageDrawableRes),
                                    contentDescription = car.name,
                                    modifier = Modifier.size(70.dp),
                                    contentScale = ContentScale.Fit
                                )
                                if (!unlocked) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color.Black.copy(alpha = 0.6f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = "Locked",
                                            tint = RacingGold,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = car.name,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = car.tag,
                                color = RacingCyan,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 2. Main Selected Car Showcase & Specifications
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = selectedTabCar.name,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp
                            )
                            Text(
                                text = selectedTabCar.description,
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }

                        if (!isUnlocked) {
                            Button(
                                onClick = { viewModel.unlockCar(selectedTabCar.id, selectedTabCar.priceCoins) },
                                colors = ButtonDefaults.buttonColors(containerColor = RacingGold),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("garage_unlock_button_${selectedTabCar.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("UNLOCK ${selectedTabCar.priceCoins}", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            if (uiState.selectedCar.id != selectedTabCar.id) {
                                Button(
                                    onClick = { viewModel.selectCar(selectedTabCar.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = RacingCyan),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("garage_select_button_${selectedTabCar.id}")
                                ) {
                                    Text("SELECT CAR", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .background(RacingGreen.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                        .border(1.dp, RacingGreen, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("EQUIPPED", color = RacingGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Performance Specs Bars
                    val engineLvl = currentUnlock?.engineLevel ?: 1
                    val handlingLvl = currentUnlock?.handlingLevel ?: 1
                    val nitroLvl = currentUnlock?.nitroLevel ?: 1

                    SpecProgressBar(
                        title = "TOP SPEED & ENGINE",
                        value = (selectedTabCar.baseTopSpeedMph + (engineLvl - 1) * 10) / 220f,
                        subtitle = "${selectedTabCar.baseTopSpeedMph + (engineLvl - 1) * 10} MPH (LVL $engineLvl)",
                        color = RacingRed,
                        onUpgrade = if (isUnlocked && engineLvl < 5) {
                            { viewModel.upgradeCarPart(selectedTabCar.id, "ENGINE", engineLvl * 200) }
                        } else null,
                        upgradeCost = engineLvl * 200
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    SpecProgressBar(
                        title = "HANDLING & STEERING",
                        value = (selectedTabCar.baseHandling + handlingLvl) / 15f,
                        subtitle = "LVL $handlingLvl / 5",
                        color = RacingCyan,
                        onUpgrade = if (isUnlocked && handlingLvl < 5) {
                            { viewModel.upgradeCarPart(selectedTabCar.id, "HANDLING", handlingLvl * 150) }
                        } else null,
                        upgradeCost = handlingLvl * 150
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    SpecProgressBar(
                        title = "NITRO CAPACITY",
                        value = (selectedTabCar.baseNitroCapacity + nitroLvl) / 15f,
                        subtitle = "LVL $nitroLvl / 5",
                        color = RacingGold,
                        onUpgrade = if (isUnlocked && nitroLvl < 5) {
                            { viewModel.upgradeCarPart(selectedTabCar.id, "NITRO", nitroLvl * 150) }
                        } else null,
                        upgradeCost = nitroLvl * 150
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3. Custom Paint Color Palette
            if (isUnlocked) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Palette, contentDescription = null, tint = RacingCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("CUSTOM PAINT FINISH", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CarCatalog.paintColors.forEach { colorHex ->
                                val isSelectedColor = (currentUnlock?.paintColorHex == colorHex)
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color(colorHex))
                                        .border(
                                            width = if (isSelectedColor) 3.dp else 0.dp,
                                            color = Color.White,
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            viewModel.updateCarPaint(selectedTabCar.id, colorHex)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelectedColor) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Replay Studio Section
                Text(
                    text = "RACE REPLAY STUDIO",
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                val latestReplay = uiState.latestReplay
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = if (latestReplay != null) RacingCyan else Color(0xFF2E384D),
                            shape = RoundedCornerShape(20.dp)
                        ),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(if (latestReplay != null) RacingRed.copy(alpha = 0.2f) else Color(0xFF1E293B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = null,
                                    tint = if (latestReplay != null) RacingRed else Color.Gray,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = if (latestReplay != null) "Last Race Replay (30s)" else "No Replay Available",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (latestReplay != null)
                                        "${latestReplay.track.displayName} • ${latestReplay.finalScore} PTS"
                                    else
                                        "Complete a race to record gameplay",
                                    color = if (latestReplay != null) RacingCyan else Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Button(
                            onClick = { showReplayDialog = true },
                            enabled = (latestReplay != null),
                            colors = ButtonDefaults.buttonColors(containerColor = RacingRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("garage_watch_replay_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("REPLAY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpecProgressBar(
    title: String,
    value: Float,
    subtitle: String,
    color: Color,
    onUpgrade: (() -> Unit)?,
    upgradeCost: Int
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(
                progress = { value.coerceIn(0f, 1f) },
                modifier = Modifier
                    .weight(1f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = color,
                trackColor = Color(0xFF1E293B)
            )

            if (onUpgrade != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onUpgrade,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(imageVector = Icons.Default.Build, contentDescription = null, tint = RacingGold, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+$upgradeCost", color = RacingGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
