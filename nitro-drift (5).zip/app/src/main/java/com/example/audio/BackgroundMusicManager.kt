package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

class BackgroundMusicManager(context: Context) {
    private val prefs = context.getSharedPreferences("bg_music_prefs", Context.MODE_PRIVATE)

    private val _isMusicMuted = MutableStateFlow(prefs.getBoolean("KEY_MUSIC_MUTED", false))
    val isMusicMuted: StateFlow<Boolean> = _isMusicMuted.asStateFlow()

    private var audioTrack: AudioTrack? = null
    private var musicJob: Job? = null
    private var isMusicRunning = false

    fun isMuted(): Boolean = _isMusicMuted.value

    fun toggleMusicMute() {
        val newMuted = !_isMusicMuted.value
        _isMusicMuted.value = newMuted
        prefs.edit().putBoolean("KEY_MUSIC_MUTED", newMuted).apply()
    }

    fun setMusicMuted(muted: Boolean) {
        _isMusicMuted.value = muted
        prefs.edit().putBoolean("KEY_MUSIC_MUTED", muted).apply()
    }

    fun startMusic(scope: CoroutineScope) {
        if (isMusicRunning) return
        isMusicRunning = true

        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()
        } catch (e: Exception) {
            isMusicRunning = false
            return
        }

        // Synthwave 16-step synth arpeggio frequencies (A minor / F / C / G synth progression)
        val bassSequence = doubleArrayOf(
            110.0, 110.0, 220.0, 164.81, // A2, A2, A3, E3
            87.31,  87.31, 174.61, 130.81, // F2, F2, F3, C3
            130.81, 130.81, 261.63, 196.00, // C3, C3, C4, G3
            98.00,  98.00, 196.00, 146.83  // G2, G2, G3, D3
        )

        val leadSequence = doubleArrayOf(
            440.0, 523.25, 659.25, 523.25, // A4, C5, E5, C5
            349.23, 440.0, 523.25, 440.0,  // F4, A4, C5, A4
            523.25, 659.25, 783.99, 659.25, // C5, E5, G5, E5
            392.00, 493.88, 587.33, 493.88  // G4, B4, D5, B4
        )

        val stepSamples = (sampleRate * 0.12).toInt() // 120ms per step

        musicJob = scope.launch(Dispatchers.Default) {
            var stepIndex = 0
            val sampleBuffer = ShortArray(stepSamples)

            while (isActive && isMusicRunning) {
                if (_isMusicMuted.value) {
                    delay(150)
                    continue
                }

                val bassFreq = bassSequence[stepIndex % bassSequence.size]
                val leadFreq = leadSequence[stepIndex % leadSequence.size]

                val bassPhaseInc = (2.0 * Math.PI * bassFreq) / sampleRate
                val leadPhaseInc = (2.0 * Math.PI * leadFreq) / sampleRate

                var bassPhase = 0.0
                var leadPhase = 0.0

                for (i in 0 until stepSamples) {
                    // Decay envelope per step
                    val env = (1.0 - (i.toDouble() / stepSamples)).coerceIn(0.1, 1.0)

                    // Bass synth tone (sawtooth mix)
                    val bassVal = (sin(bassPhase) + 0.5 * sin(bassPhase * 2.0)) * 0.25 * env
                    // Lead melody synth tone
                    val leadVal = (sin(leadPhase) + 0.3 * sin(leadPhase * 3.0)) * 0.18 * env

                    val sampleInt = ((bassVal + leadVal) * Short.MAX_VALUE).toInt()
                    sampleBuffer[i] = sampleInt.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()

                    bassPhase += bassPhaseInc
                    leadPhase += leadPhaseInc
                }

                audioTrack?.write(sampleBuffer, 0, stepSamples)
                stepIndex++
            }
        }
    }

    fun stopMusic() {
        isMusicRunning = false
        musicJob?.cancel()
        musicJob = null
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null
    }
}
