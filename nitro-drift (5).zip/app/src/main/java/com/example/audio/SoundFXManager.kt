package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

class SoundFXManager(private val context: Context) {
    private var toneGenerator: ToneGenerator? = null
    private var isMuted = false
    
    // Engine sound synthesizer track
    private var engineAudioTrack: AudioTrack? = null
    private var isEngineSynthRunning = false
    private var synthJob: Job? = null
    private var currentRpmRatio = 0.2f

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
        } catch (e: Exception) {
            toneGenerator = null
        }
    }

    fun setMuted(muted: Boolean) {
        isMuted = muted
    }

    fun isMuted(): Boolean = isMuted

    fun playCoinSound() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 60)
        } catch (_: Exception) {}
    }

    fun playNitroSound() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 180)
        } catch (_: Exception) {}
    }

    fun playCrashSound() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_SUP_ERROR, 250)
        } catch (_: Exception) {}
    }

    fun playCloseCallSound() {
        if (isMuted) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 50)
        } catch (_: Exception) {}
    }

    fun startEngineSound(scope: CoroutineScope) {
        if (isEngineSynthRunning || isMuted) return
        isEngineSynthRunning = true

        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            engineAudioTrack = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            engineAudioTrack?.play()
        } catch (e: Exception) {
            isEngineSynthRunning = false
            return
        }

        synthJob = scope.launch(Dispatchers.Default) {
            val numSamples = 1024
            val sampleBuffer = ShortArray(numSamples)
            var phase = 0.0

            while (isActive && isEngineSynthRunning) {
                if (isMuted) {
                    delay(100)
                    continue
                }

                val freq = 50.0 + (currentRpmRatio * 350.0) // Engine frequency 50Hz to 400Hz
                val phaseIncrement = (2.0 * Math.PI * freq) / sampleRate

                for (i in 0 until numSamples) {
                    // Sawtooth / Sine mix with harmonic for throaty engine rumble
                    val val1 = sin(phase)
                    val val2 = sin(phase * 2.0) * 0.4
                    val val3 = sin(phase * 3.0) * 0.2
                    val sample = ((val1 + val2 + val3) * 0.25 * Short.MAX_VALUE).toInt()
                    sampleBuffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()

                    phase += phaseIncrement
                    if (phase >= 2.0 * Math.PI) {
                        phase -= 2.0 * Math.PI
                    }
                }

                engineAudioTrack?.write(sampleBuffer, 0, numSamples)
                delay(10)
            }
        }
    }

    fun updateEnginePitch(rpmRatio: Float) {
        currentRpmRatio = rpmRatio.coerceIn(0.1f, 1.0f)
    }

    fun stopEngineSound() {
        isEngineSynthRunning = false
        synthJob?.cancel()
        synthJob = null
        try {
            engineAudioTrack?.stop()
            engineAudioTrack?.release()
        } catch (_: Exception) {}
        engineAudioTrack = null
    }

    fun release() {
        stopEngineSound()
        try {
            toneGenerator?.release()
        } catch (_: Exception) {}
        toneGenerator = null
    }
}
