package com.example.audio

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class HapticsManager(context: Context) {
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private var isMuted = false
    private var lastGear = 1
    private var lastVibrationTimeMs = 0L

    fun setMuted(muted: Boolean) {
        isMuted = muted
    }

    fun isMuted(): Boolean = isMuted

    fun toggleMute(): Boolean {
        isMuted = !isMuted
        if (!isMuted) {
            triggerGearShiftHaptic()
        }
        return isMuted
    }

    /**
     * Heavy or medium collision vibration when crashing or taking traffic damage.
     */
    fun triggerCollisionHaptic(isHeavy: Boolean = false) {
        if (isMuted || vibrator == null || !vibrator.hasVibrator()) return
        val duration = if (isHeavy) 250L else 130L
        val amplitude = if (isHeavy) 255 else 180

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(duration)
        }
    }

    /**
     * Crisp sharp pulse trigger on gear shifts (e.g. 1st -> 2nd -> 3rd gear).
     */
    fun triggerGearShiftHaptic() {
        if (isMuted || vibrator == null || !vibrator.hasVibrator()) return
        val now = System.currentTimeMillis()
        if (now - lastVibrationTimeMs < 100) return
        lastVibrationTimeMs = now

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(35L, 160))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(30L)
        }
    }

    /**
     * Rapid subtle tick/vibration for active drifting / tire sliding at high steering angles.
     */
    fun triggerDriftHaptic(intensity: Float = 1.0f) {
        if (isMuted || vibrator == null || !vibrator.hasVibrator()) return
        val now = System.currentTimeMillis()
        if (now - lastVibrationTimeMs < 80) return
        lastVibrationTimeMs = now

        val duration = (25 * intensity).toLong().coerceIn(15L, 40L)
        val amplitude = (120 * intensity).toInt().coerceIn(60, 200)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(duration)
        }
    }

    /**
     * Boost rumble when nitro is engaged.
     */
    fun triggerNitroHaptic() {
        if (isMuted || vibrator == null || !vibrator.hasVibrator()) return
        val now = System.currentTimeMillis()
        if (now - lastVibrationTimeMs < 90) return
        lastVibrationTimeMs = now

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(45L, 220))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(40L)
        }
    }

    /**
     * Quick tick for collecting coins, close calls, or powerups.
     */
    fun triggerCloseCallHaptic() {
        if (isMuted || vibrator == null || !vibrator.hasVibrator()) return
        val now = System.currentTimeMillis()
        if (now - lastVibrationTimeMs < 100) return
        lastVibrationTimeMs = now

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK))
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(50L, 140))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(45L)
        }
    }

    fun checkAndTriggerGearShift(currentGear: Int) {
        if (currentGear != lastGear) {
            lastGear = currentGear
            triggerGearShiftHaptic()
        }
    }

    fun resetGearState(initialGear: Int = 1) {
        lastGear = initialGear
    }
}
