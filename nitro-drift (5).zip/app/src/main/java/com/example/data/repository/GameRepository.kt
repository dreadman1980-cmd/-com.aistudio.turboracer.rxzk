package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.db.CarUnlockEntity
import com.example.data.db.DailyMissionEntity
import com.example.data.db.RaceScoreEntity
import com.example.data.db.UserStatsEntity
import com.example.data.model.CarCatalog
import com.example.game.RaceReplaySession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

private data class MissionTemplate(
    val type: String,
    val title: String,
    val description: String,
    val targetAmount: Int,
    val rewardCoins: Int
)

class GameRepository(private val db: AppDatabase) {
    val userStats: Flow<UserStatsEntity?> = db.userStatsDao().getUserStats()
    val carUnlocks: Flow<List<CarUnlockEntity>> = db.carUnlockDao().getAllCarUnlocks()
    val topScores: Flow<List<RaceScoreEntity>> = db.raceScoreDao().getTopScores()
    val recentScores: Flow<List<RaceScoreEntity>> = db.raceScoreDao().getRecentScores()

    private val _latestReplay = MutableStateFlow<RaceReplaySession?>(null)
    val latestReplay: StateFlow<RaceReplaySession?> = _latestReplay.asStateFlow()

    fun saveReplaySession(session: RaceReplaySession) {
        _latestReplay.value = session
    }

    fun getCurrentDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun getDailyMissions(dateStr: String): Flow<List<DailyMissionEntity>> {
        return db.dailyMissionDao().getMissionsForDate(dateStr)
    }

    suspend fun ensureDailyMissionsForToday(): List<DailyMissionEntity> {
        val todayStr = getCurrentDateString()
        var existing = db.dailyMissionDao().getMissionsForDateOnce(todayStr)
        if (existing.size < 3) {
            // Delete old missions from previous days
            db.dailyMissionDao().deleteOldMissions(todayStr)

            val templates = listOf(
                MissionTemplate("OVERTAKE_CARS", "Highway Overtaker", "Overtake 10 traffic vehicles closely", 10, 300),
                MissionTemplate("OVERTAKE_CARS", "Traffic Master", "Overtake 20 traffic vehicles", 20, 500),
                MissionTemplate("DISTANCE_METERS", "Long Distance Runner", "Drive 1,000 meters in races", 1000, 350),
                MissionTemplate("DISTANCE_METERS", "Endless Tour", "Drive 2,500 meters in races", 2500, 600),
                MissionTemplate("COLLECT_COINS", "Coin Hunter", "Collect 30 coins on the highway", 30, 250),
                MissionTemplate("COLLECT_COINS", "Treasure Collector", "Collect 60 coins on the highway", 60, 450),
                MissionTemplate("REACH_SPEED", "Speed Demon", "Reach a top speed of 150 MPH", 150, 300),
                MissionTemplate("REACH_SPEED", "Sonic Rush", "Reach a top speed of 180 MPH", 180, 500),
                MissionTemplate("CLOSE_CALLS", "Daredevil", "Perform 5 near-miss close calls", 5, 400),
                MissionTemplate("PLAY_RACES", "Daily Racer", "Complete 3 race sessions", 3, 200),
                MissionTemplate("SCORE_POINTS", "High Scorer", "Score 3,000 total points in races", 3000, 400)
            )

            val selectedTemplates = templates.shuffled().take(3)
            val newMissions = selectedTemplates.mapIndexed { index, tmpl ->
                DailyMissionEntity(
                    missionId = "m_${todayStr}_${index}_${tmpl.type}",
                    type = tmpl.type,
                    title = tmpl.title,
                    description = tmpl.description,
                    targetAmount = tmpl.targetAmount,
                    currentProgress = 0,
                    rewardCoins = tmpl.rewardCoins,
                    isCompleted = false,
                    isClaimed = false,
                    dateAssigned = todayStr
                )
            }
            db.dailyMissionDao().insertOrUpdateMissions(newMissions)
            existing = newMissions
        }
        return existing
    }

    suspend fun claimMissionReward(missionId: String): Boolean {
        val todayStr = getCurrentDateString()
        val missions = db.dailyMissionDao().getMissionsForDateOnce(todayStr)
        val mission = missions.find { it.missionId == missionId } ?: return false

        if (mission.isCompleted && !mission.isClaimed) {
            val updatedMission = mission.copy(isClaimed = true)
            db.dailyMissionDao().insertOrUpdateMission(updatedMission)

            val stats = db.userStatsDao().getUserStatsOnce() ?: UserStatsEntity()
            val updatedStats = stats.copy(coinsBalance = stats.coinsBalance + mission.rewardCoins)
            db.userStatsDao().insertOrUpdateUserStats(updatedStats)
            return true
        }
        return false
    }

    suspend fun initializeDefaultsIfEmpty() {
        var stats = db.userStatsDao().getUserStatsOnce()
        if (stats == null) {
            stats = UserStatsEntity(
                driverLevel = 1,
                driverXp = 0,
                coinsBalance = 600,
                selectedCarId = "car_apex",
                totalRaces = 0,
                totalDistanceMeters = 0f
            )
            db.userStatsDao().insertOrUpdateUserStats(stats)
        }

        // Initialize car unlocks
        val defaultUnlocks = CarCatalog.defaultCars.map { car ->
            CarUnlockEntity(
                carId = car.id,
                isUnlocked = (car.priceCoins == 0),
                paintColorHex = car.primaryColorHex,
                engineLevel = 1,
                handlingLevel = 1,
                nitroLevel = 1
            )
        }
        db.carUnlockDao().insertDefaultCarUnlocks(defaultUnlocks)

        // Ensure today's 3 daily missions
        ensureDailyMissionsForToday()
    }

    suspend fun setSelectedCar(carId: String) {
        val currentStats = db.userStatsDao().getUserStatsOnce() ?: UserStatsEntity()
        db.userStatsDao().insertOrUpdateUserStats(currentStats.copy(selectedCarId = carId))
    }

    suspend fun unlockCar(carId: String, price: Int): Boolean {
        val currentStats = db.userStatsDao().getUserStatsOnce() ?: return false
        if (currentStats.coinsBalance < price) return false

        val updatedStats = currentStats.copy(coinsBalance = currentStats.coinsBalance - price)
        db.userStatsDao().insertOrUpdateUserStats(updatedStats)

        val existingUnlock = db.carUnlockDao().getCarUnlock(carId)
            ?: CarUnlockEntity(carId = carId)
        db.carUnlockDao().insertOrUpdateCarUnlock(existingUnlock.copy(isUnlocked = true))
        return true
    }

    suspend fun updateCarPaint(carId: String, colorHex: Long) {
        val existing = db.carUnlockDao().getCarUnlock(carId) ?: return
        db.carUnlockDao().insertOrUpdateCarUnlock(existing.copy(paintColorHex = colorHex))
    }

    suspend fun upgradeCarPart(carId: String, partType: String, cost: Int): Boolean {
        val currentStats = db.userStatsDao().getUserStatsOnce() ?: return false
        if (currentStats.coinsBalance < cost) return false

        val carUnlock = db.carUnlockDao().getCarUnlock(carId) ?: return false

        val updatedUnlock = when (partType) {
            "ENGINE" -> carUnlock.copy(engineLevel = (carUnlock.engineLevel + 1).coerceAtMost(5))
            "HANDLING" -> carUnlock.copy(handlingLevel = (carUnlock.handlingLevel + 1).coerceAtMost(5))
            "NITRO" -> carUnlock.copy(nitroLevel = (carUnlock.nitroLevel + 1).coerceAtMost(5))
            else -> carUnlock
        }

        db.userStatsDao().insertOrUpdateUserStats(currentStats.copy(coinsBalance = currentStats.coinsBalance - cost))
        db.carUnlockDao().insertOrUpdateCarUnlock(updatedUnlock)
        return true
    }

    suspend fun recordRaceResult(
        score: Int,
        distanceMeters: Float,
        maxSpeedMph: Int,
        coinsEarned: Int,
        closeCalls: Int,
        trackName: String,
        gameMode: String
    ) {
        db.raceScoreDao().insertScore(
            RaceScoreEntity(
                score = score,
                distanceMeters = distanceMeters,
                maxSpeedMph = maxSpeedMph,
                coinsCollected = coinsEarned,
                closeCalls = closeCalls,
                trackName = trackName,
                gameMode = gameMode
            )
        )

        val currentStats = db.userStatsDao().getUserStatsOnce() ?: UserStatsEntity()
        val newXp = currentStats.driverXp + (score / 10) + (coinsEarned * 2)
        val newLevel = 1 + (newXp / 500)
        val updatedStats = currentStats.copy(
            driverLevel = newLevel,
            driverXp = newXp,
            coinsBalance = currentStats.coinsBalance + coinsEarned,
            totalRaces = currentStats.totalRaces + 1,
            totalDistanceMeters = currentStats.totalDistanceMeters + distanceMeters
        )
        db.userStatsDao().insertOrUpdateUserStats(updatedStats)

        // Progress Daily Missions
        val todayStr = getCurrentDateString()
        val activeMissions = db.dailyMissionDao().getMissionsForDateOnce(todayStr)
        val updatedMissions = activeMissions.map { m ->
            var newProgress = m.currentProgress
            when (m.type) {
                "OVERTAKE_CARS" -> newProgress += closeCalls
                "DISTANCE_METERS" -> newProgress += distanceMeters.toInt()
                "COLLECT_COINS" -> newProgress += coinsEarned
                "REACH_SPEED" -> newProgress = maxOf(newProgress, maxSpeedMph)
                "CLOSE_CALLS" -> newProgress += closeCalls
                "PLAY_RACES" -> newProgress += 1
                "SCORE_POINTS" -> newProgress += score
            }
            val completed = (newProgress >= m.targetAmount)
            m.copy(
                currentProgress = newProgress.coerceAtMost(m.targetAmount),
                isCompleted = completed || m.isCompleted
            )
        }
        db.dailyMissionDao().insertOrUpdateMissions(updatedMissions)
    }
}
