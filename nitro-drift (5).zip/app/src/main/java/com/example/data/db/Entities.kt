package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "race_scores")
data class RaceScoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val score: Int,
    val distanceMeters: Float,
    val maxSpeedMph: Int,
    val coinsCollected: Int,
    val closeCalls: Int,
    val trackName: String,
    val gameMode: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_stats")
data class UserStatsEntity(
    @PrimaryKey val id: Int = 1,
    val driverLevel: Int = 1,
    val driverXp: Int = 0,
    val coinsBalance: Int = 500,
    val selectedCarId: String = "car_apex",
    val totalRaces: Int = 0,
    val totalDistanceMeters: Float = 0f
)

@Entity(tableName = "car_unlocks")
data class CarUnlockEntity(
    @PrimaryKey val carId: String,
    val isUnlocked: Boolean = false,
    val paintColorHex: Long = 0xFFFF2A55,
    val engineLevel: Int = 1,
    val handlingLevel: Int = 1,
    val nitroLevel: Int = 1
)

@Entity(tableName = "daily_missions")
data class DailyMissionEntity(
    @PrimaryKey val missionId: String,
    val type: String,
    val title: String,
    val description: String,
    val targetAmount: Int,
    val currentProgress: Int = 0,
    val rewardCoins: Int,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false,
    val dateAssigned: String
)
