package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RaceScoreDao {
    @Query("SELECT * FROM race_scores ORDER BY score DESC LIMIT 20")
    fun getTopScores(): Flow<List<RaceScoreEntity>>

    @Query("SELECT * FROM race_scores ORDER BY timestamp DESC LIMIT 10")
    fun getRecentScores(): Flow<List<RaceScoreEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScore(score: RaceScoreEntity)
}

@Dao
interface UserStatsDao {
    @Query("SELECT * FROM user_stats WHERE id = 1")
    fun getUserStats(): Flow<UserStatsEntity?>

    @Query("SELECT * FROM user_stats WHERE id = 1")
    suspend fun getUserStatsOnce(): UserStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUserStats(stats: UserStatsEntity)
}

@Dao
interface CarUnlockDao {
    @Query("SELECT * FROM car_unlocks")
    fun getAllCarUnlocks(): Flow<List<CarUnlockEntity>>

    @Query("SELECT * FROM car_unlocks WHERE carId = :carId")
    suspend fun getCarUnlock(carId: String): CarUnlockEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateCarUnlock(carUnlock: CarUnlockEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDefaultCarUnlocks(unlocks: List<CarUnlockEntity>)
}

@Dao
interface DailyMissionDao {
    @Query("SELECT * FROM daily_missions WHERE dateAssigned = :dateStr")
    fun getMissionsForDate(dateStr: String): Flow<List<DailyMissionEntity>>

    @Query("SELECT * FROM daily_missions WHERE dateAssigned = :dateStr")
    suspend fun getMissionsForDateOnce(dateStr: String): List<DailyMissionEntity>

    @Query("SELECT * FROM daily_missions")
    suspend fun getAllMissionsOnce(): List<DailyMissionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateMissions(missions: List<DailyMissionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateMission(mission: DailyMissionEntity)

    @Query("DELETE FROM daily_missions WHERE dateAssigned != :currentDateStr")
    suspend fun deleteOldMissions(currentDateStr: String)
}
