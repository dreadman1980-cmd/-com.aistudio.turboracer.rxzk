package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        RaceScoreEntity::class,
        UserStatsEntity::class,
        CarUnlockEntity::class,
        DailyMissionEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun raceScoreDao(): RaceScoreDao
    abstract fun userStatsDao(): UserStatsDao
    abstract fun carUnlockDao(): CarUnlockDao
    abstract fun dailyMissionDao(): DailyMissionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "turbo_racer_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
