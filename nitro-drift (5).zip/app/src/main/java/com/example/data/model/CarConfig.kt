package com.example.data.model

import com.example.R

data class CarPreset(
    val id: String,
    val name: String,
    val tag: String,
    val baseTopSpeedMph: Int,
    val baseAcceleration: Int, // 1 - 10
    val baseHandling: Int, // 1 - 10
    val baseNitroCapacity: Int, // 1 - 10
    val priceCoins: Int,
    val imageDrawableRes: Int,
    val primaryColorHex: Long,
    val description: String
)

object CarCatalog {
    val defaultCars = listOf(
        CarPreset(
            id = "car_apex",
            name = "Apex GT",
            tag = "BALANCED SUPERCAR",
            baseTopSpeedMph = 140,
            baseAcceleration = 6,
            baseHandling = 7,
            baseNitroCapacity = 6,
            priceCoins = 0, // Starter car
            imageDrawableRes = R.drawable.img_car_apex_1785168558962,
            primaryColorHex = 0xFFFF2A55, // Red
            description = "Lightweight twin-turbo V8. Nimble maneuverability for tight highway weaves."
        ),
        CarPreset(
            id = "car_muscle",
            name = "Viper Interceptor",
            tag = "HEAVYWEIGHT MUSCLE",
            baseTopSpeedMph = 160,
            baseAcceleration = 8,
            baseHandling = 5,
            baseNitroCapacity = 7,
            priceCoins = 750,
            imageDrawableRes = R.drawable.img_car_muscle_1785168581880,
            primaryColorHex = 0xFFFFC107, // Gold/Yellow
            description = "Raw V12 supercharged American muscle. Incredible straight-line speed."
        ),
        CarPreset(
            id = "car_cyber",
            name = "Cyber Phantom 3000",
            tag = "HYPERCAR PROTOTYPE",
            baseTopSpeedMph = 190,
            baseAcceleration = 9,
            baseHandling = 9,
            baseNitroCapacity = 10,
            priceCoins = 2000,
            imageDrawableRes = R.drawable.img_car_cyber_1785168571821,
            primaryColorHex = 0xFF00F0FF, // Cyan
            description = "Plasma-boosted hover-rail prototype with extreme acceleration and nitro duration."
        )
    )

    val paintColors = listOf(
        0xFFFF2A55, // Flame Red
        0xFF00F0FF, // Cyber Cyan
        0xFFFFD700, // Gold
        0xFF00E676, // Neon Green
        0xFFA855F7, // Purple Pulse
        0xFF3B82F6, // Electric Blue
        0xFF1E293B  // Stealth Black
    )

    fun getCarById(id: String): CarPreset {
        return defaultCars.find { it.id == id } ?: defaultCars.first()
    }
}
