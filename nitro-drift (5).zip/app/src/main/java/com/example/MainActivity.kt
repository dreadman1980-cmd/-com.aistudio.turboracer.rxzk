package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.GameViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GarageScreen
import com.example.ui.screens.RacingScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.theme.TurboRacerTheme

enum class ScreenRoute {
    DASHBOARD,
    GARAGE,
    RACING,
    STATS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TurboRacerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TurboRacerApp()
                }
            }
        }
    }
}

@Composable
fun TurboRacerApp(viewModel: GameViewModel = viewModel()) {
    var currentRoute by remember { mutableStateOf(ScreenRoute.DASHBOARD) }

    when (currentRoute) {
        ScreenRoute.DASHBOARD -> {
            DashboardScreen(
                viewModel = viewModel,
                onStartRaceClick = {
                    viewModel.startRace()
                    currentRoute = ScreenRoute.RACING
                },
                onGarageClick = {
                    currentRoute = ScreenRoute.GARAGE
                },
                onStatsClick = {
                    currentRoute = ScreenRoute.STATS
                }
            )
        }
        ScreenRoute.GARAGE -> {
            GarageScreen(
                viewModel = viewModel,
                onBackToMain = {
                    currentRoute = ScreenRoute.DASHBOARD
                }
            )
        }
        ScreenRoute.RACING -> {
            RacingScreen(
                viewModel = viewModel,
                onExitToGarage = {
                    currentRoute = ScreenRoute.DASHBOARD
                }
            )
        }
        ScreenRoute.STATS -> {
            StatsScreen(
                viewModel = viewModel,
                onBackToMain = {
                    currentRoute = ScreenRoute.DASHBOARD
                }
            )
        }
    }
}
