package com.example.game

enum class GameMode(val displayName: String, val description: String) {
    ENDLESS_HIGHWAY("Endless Highway", "Weave through heavy traffic, dodge cars, and earn close call combo bonuses."),
    TIME_TRIAL("Time Trial", "Hit race checkpoints before the timer runs out on curved circuit roads."),
    POLICE_PURSUIT("Police Pursuit", "Outrun sirens, aggressive police squad cars, and tactical road spikes!")
}

enum class TrackEnvironment(val displayName: String, val asphaltColor: Long, val borderLineColor: Long, val bgGradientStart: Long, val bgGradientEnd: Long) {
    NEON_CITY("Neon Highway", 0xFF171D28, 0xFF00F0FF, 0xFF090D16, 0xFF121B2B),
    DESERT_STORM("Desert Canyon", 0xFF2A231C, 0xFFFFB74D, 0xFF1C130A, 0xFF3D2714),
    MIDNIGHT_CIRCUIT("Midnight Circuit", 0xFF11141A, 0xFFFF2A55, 0xFF05070A, 0xFF1A0A12)
}

enum class EntityType {
    TRAFFIC_SEDAN,
    TRAFFIC_TRUCK,
    POLICE_CAR,
    ROAD_SPIKE,
    COIN,
    POWERUP_NITRO,
    POWERUP_SHIELD,
    POWERUP_REPAIR,
    POWERUP_MAGNET,
    OIL_SLICK
}

data class GameObject(
    val id: Long,
    var lane: Int, // 0, 1, 2, 3 (for 4-lane highway)
    var xNormalized: Float, // -1f to 1f across road width
    var yNormalized: Float, // 0f (top) to 1f (bottom)
    val widthNormalized: Float,
    val heightNormalized: Float,
    val type: EntityType,
    var speedNormalized: Float, // relative speed relative to player
    val colorHex: Long = 0xFFCCCCCC
)

data class ParticleFX(
    val id: Long,
    var xNorm: Float,
    var yNorm: Float,
    var vx: Float,
    var vy: Float,
    var radius: Float,
    var alpha: Float,
    val colorHex: Long,
    val maxAgeFrames: Int,
    var ageFrames: Int = 0
)

data class FloatingMessage(
    val id: Long,
    val text: String,
    val colorHex: Long,
    var yNorm: Float,
    var alpha: Float,
    var durationMs: Long
)

enum class GameStatus {
    IDLE,
    COUNTDOWN,
    PLAYING,
    PAUSED,
    GAME_OVER
}

enum class WeatherCondition(val displayName: String, val description: String) {
    CLEAR("Clear Sky", "Optimal road grip & 100% full visibility"),
    NEON_RAIN("Neon Rain", "Slanted rain streaks, splash ripples & wet asphalt reflections"),
    CYBER_SNOW("Cyber Snow", "Floating frost flakes with atmospheric fog haze")
}

data class WeatherParticle(
    val id: Long,
    var xNorm: Float, // 0f to 1f across screen
    var yNorm: Float, // 0f to 1f down screen
    var speedY: Float,
    var speedX: Float,
    var length: Float, // for rain streak
    var radius: Float, // for snow flake
    var alpha: Float,
    val colorHex: Long
)

data class GameEngineState(
    val status: GameStatus = GameStatus.IDLE,
    val mode: GameMode = GameMode.ENDLESS_HIGHWAY,
    val track: TrackEnvironment = TrackEnvironment.NEON_CITY,
    val weather: WeatherCondition = WeatherCondition.NEON_RAIN,
    val countdownSeconds: Int = 3,
    
    // Player car position & physics
    val playerLane: Int = 1,
    val playerXNorm: Float = -0.25f, // Range [-0.8f, 0.8f]
    val speedMph: Float = 0f,
    val targetSpeedMph: Float = 0f,
    val maxSpeedMph: Float = 140f,
    val accelerationStat: Float = 1.0f,
    val handlingStat: Float = 1.0f,
    val rpmRatio: Float = 0.2f,
    val gear: Int = 1,
    
    // Status & Powerups
    val health: Int = 100,
    val maxHealth: Int = 100,
    val nitroLevel: Float = 100f, // 0..100
    val isNitroActive: Boolean = false,
    val hasShield: Boolean = false,
    val isMagnetActive: Boolean = false,
    val magnetTimerSeconds: Float = 0f,
    val shieldHitsRemaining: Int = 0,
    
    // Metrics
    val score: Int = 0,
    val distanceMeters: Float = 0f,
    val coinsCollected: Int = 0,
    val closeCalls: Int = 0,
    val comboMultiplier: Int = 1,
    val timeRemainingSeconds: Float = 60f, // For Time Trial
    
    // Game Objects
    val objects: List<GameObject> = emptyList(),
    val particles: List<ParticleFX> = emptyList(),
    val weatherParticles: List<WeatherParticle> = emptyList(),
    val messages: List<FloatingMessage> = emptyList(),
    val roadOffsetNormalized: Float = 0f,
    
    val closeCallAlert: String? = null
)
