package com.example.game

data class ReplayFrame(
    val frameTimeMs: Long,
    val playerXNorm: Float,
    val speedMph: Float,
    val roadOffsetNormalized: Float,
    val score: Int,
    val coinsCollected: Int,
    val health: Int,
    val isNitroActive: Boolean,
    val hasShield: Boolean,
    val closeCallAlert: String?,
    val objects: List<GameObject>,
    val particles: List<ParticleFX> = emptyList()
)

data class RaceReplaySession(
    val id: String,
    val timestamp: Long,
    val durationSeconds: Float,
    val carId: String,
    val carPaintHex: Long,
    val track: TrackEnvironment,
    val weather: WeatherCondition,
    val mode: GameMode,
    val finalScore: Int,
    val maxSpeedMph: Int,
    val frames: List<ReplayFrame>
)
