package com.example.game

import com.example.audio.HapticsManager
import com.example.audio.SoundFXManager
import com.example.data.db.CarUnlockEntity
import com.example.data.model.CarPreset
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

class GameEngine(
    private val soundFX: SoundFXManager,
    private val haptics: HapticsManager? = null
) {
    private var objectIdCounter = 1L
    private var particleIdCounter = 1L
    private var messageIdCounter = 1L

    private var spawnTimerFrames = 0
    private var lastCloseCallFrame = 0

    fun initGame(
        selectedCar: CarPreset,
        carUnlock: CarUnlockEntity?,
        mode: GameMode,
        track: TrackEnvironment,
        weather: WeatherCondition = WeatherCondition.NEON_RAIN
    ): GameEngineState {
        objectIdCounter = 1L
        particleIdCounter = 1L
        messageIdCounter = 1L
        spawnTimerFrames = 0
        lastCloseCallFrame = 0
        haptics?.resetGearState(1)

        val engineLevel = carUnlock?.engineLevel ?: 1
        val handlingLevel = carUnlock?.handlingLevel ?: 1
        val nitroLevel = carUnlock?.nitroLevel ?: 1

        val maxSpeed = selectedCar.baseTopSpeedMph + (engineLevel - 1) * 12
        val accel = (selectedCar.baseAcceleration + (engineLevel - 1) * 0.8f) / 5f
        val handling = (selectedCar.baseHandling + (handlingLevel - 1) * 0.8f) / 5f

        val weatherParticlesList = generateInitialWeatherParticles(weather)

        return GameEngineState(
            status = GameStatus.COUNTDOWN,
            mode = mode,
            track = track,
            weather = weather,
            countdownSeconds = 3,
            playerLane = 1,
            playerXNorm = -0.20f,
            speedMph = 0f,
            targetSpeedMph = 60f,
            maxSpeedMph = maxSpeed.toFloat(),
            accelerationStat = accel,
            handlingStat = handling,
            rpmRatio = 0.2f,
            gear = 1,
            health = 100,
            maxHealth = 100,
            nitroLevel = 100f,
            timeRemainingSeconds = if (mode == GameMode.TIME_TRIAL) 45f else 0f,
            weatherParticles = weatherParticlesList
        )
    }

    fun update(
        currentState: GameEngineState,
        deltaSeconds: Float,
        steeringInput: Float, // -1f (left) to +1f (right)
        isAccelerating: Boolean,
        isBraking: Boolean,
        isNitroRequested: Boolean
    ): GameEngineState {
        if (currentState.status != GameStatus.PLAYING) {
            return currentState
        }

        var state = currentState

        // 1. Time Trial countdown
        if (state.mode == GameMode.TIME_TRIAL) {
            val newTime = state.timeRemainingSeconds - deltaSeconds
            if (newTime <= 0f) {
                soundFX.playCrashSound()
                return state.copy(
                    status = GameStatus.GAME_OVER,
                    timeRemainingSeconds = 0f,
                    closeCallAlert = "TIME EXPIRED!"
                )
            }
            state = state.copy(timeRemainingSeconds = newTime)
        }

        // 2. Nitro logic
        var activeNitro = state.isNitroActive
        var currentNitroLevel = state.nitroLevel

        if (isNitroRequested && currentNitroLevel > 0f) {
            activeNitro = true
            currentNitroLevel = (currentNitroLevel - (35f * deltaSeconds)).coerceAtLeast(0f)
            soundFX.playNitroSound()
            haptics?.triggerNitroHaptic()
        } else {
            activeNitro = false
            currentNitroLevel = (currentNitroLevel + (5f * deltaSeconds)).coerceAtMost(100f)
        }

        // 3. Player Speed physics
        val baseTargetSpeed = when {
            isNitroRequested && currentNitroLevel > 0f -> state.maxSpeedMph * 1.35f
            isAccelerating -> state.maxSpeedMph
            isBraking -> 30f
            else -> 65f
        }

        val accelRate = if (isNitroRequested) 120f else (60f * state.accelerationStat)
        val speedDiff = baseTargetSpeed - state.speedMph
        val newSpeed = (state.speedMph + speedDiff * deltaSeconds * (accelRate / 100f))
            .coerceIn(0f, state.maxSpeedMph * 1.4f)

        // Engine sound pitch & gear calculation
        val rpm = ((newSpeed / state.maxSpeedMph) * 1.2f).coerceIn(0.15f, 1.0f)
        soundFX.updateEnginePitch(rpm)
        val gear = ((newSpeed / 30f).toInt() + 1).coerceIn(1, 6)
        haptics?.checkAndTriggerGearShift(gear)

        // 4. Steering Movement
        val steerSpeed = 2.4f * state.handlingStat
        val newX = (state.playerXNorm + steeringInput * steerSpeed * deltaSeconds)
            .coerceIn(-0.78f, 0.78f)

        // Drifting / Tire sliding feedback when steering hard at speed
        if (abs(steeringInput) > 0.45f && newSpeed > 35f) {
            haptics?.triggerDriftHaptic(intensity = abs(steeringInput))
        }

        // Determine current lane from playerX
        val lane = when {
            newX < -0.40f -> 0
            newX < 0.0f -> 1
            newX < 0.40f -> 2
            else -> 3
        }

        // 5. Distance & Score accumulation
        val distanceCovered = (newSpeed * 0.44704f) * deltaSeconds // converted to meters
        val newDistance = state.distanceMeters + distanceCovered
        val speedFactor = (newSpeed / 50f).coerceAtLeast(1f)
        val newScore = state.score + (distanceCovered * speedFactor * state.comboMultiplier).toInt()

        // Road scroll offset
        val scrollOffset = (state.roadOffsetNormalized + (newSpeed / 120f) * deltaSeconds) % 1.0f

        // 6. Magnet timer
        val newMagnetTimer = (state.magnetTimerSeconds - deltaSeconds).coerceAtLeast(0f)
        val magnetActive = newMagnetTimer > 0f

        // 7. Object spawning
        spawnTimerFrames++
        val newObjectsList = state.objects.toMutableList()

        val spawnInterval = when (state.mode) {
            GameMode.ENDLESS_HIGHWAY -> (45 - (newSpeed / 10f).toInt()).coerceAtLeast(15)
            GameMode.POLICE_PURSUIT -> (35 - (newSpeed / 10f).toInt()).coerceAtLeast(12)
            GameMode.TIME_TRIAL -> 30
        }

        if (spawnTimerFrames >= spawnInterval) {
            spawnTimerFrames = 0
            spawnNewObjects(newObjectsList, state)
        }

        // 8. Update objects movement & particle effects
        val updatedParticles = state.particles.toMutableList()
        val updatedMessages = state.messages.toMutableList()
        val objectsToRemove = mutableSetOf<Long>()

        var newHealth = state.health
        var newCoins = state.coinsCollected
        var newCloseCalls = state.closeCalls
        var newCombo = state.comboMultiplier
        var shieldHits = state.shieldHitsRemaining
        var addTimeSeconds = 0f
        var alertMessage: String? = state.closeCallAlert

        // Spawn exhaust / nitro particles
        if (activeNitro || newSpeed > 80f) {
            spawnExhaustParticles(updatedParticles, newX, activeNitro)
        }

        // Process active objects
        for (obj in newObjectsList) {
            // Rel Speed
            val relSpeed = when (obj.type) {
                EntityType.TRAFFIC_SEDAN -> (newSpeed - 60f) / 100f
                EntityType.TRAFFIC_TRUCK -> (newSpeed - 45f) / 100f
                EntityType.POLICE_CAR -> (newSpeed - 75f) / 100f
                EntityType.ROAD_SPIKE -> newSpeed / 100f
                else -> newSpeed / 100f // Coins / Powerups
            }

            obj.yNormalized += relSpeed * deltaSeconds * 1.5f

            // Magnet pulling coins
            if (magnetActive && (obj.type == EntityType.COIN)) {
                val dx = newX - obj.xNormalized
                val dy = 0.80f - obj.yNormalized
                obj.xNormalized += dx * deltaSeconds * 4f
                obj.yNormalized += dy * deltaSeconds * 4f
            }

            // Check collision with player
            val playerY = 0.80f
            val isIntersectingX = abs(obj.xNormalized - newX) < 0.18f
            val isIntersectingY = abs(obj.yNormalized - playerY) < 0.12f

            if (isIntersectingX && isIntersectingY) {
                when (obj.type) {
                    EntityType.COIN -> {
                        newCoins += 1
                        soundFX.playCoinSound()
                        objectsToRemove.add(obj.id)
                        spawnSparkleParticles(updatedParticles, obj.xNormalized, obj.yNormalized, 0xFFFFD700)
                    }
                    EntityType.POWERUP_NITRO -> {
                        currentNitroLevel = 100f
                        soundFX.playNitroSound()
                        objectsToRemove.add(obj.id)
                        updatedMessages.add(FloatingMessage(messageIdCounter++, "MAX NITRO!", 0xFF00F0FF, playerY - 0.1f, 1f, 1200L))
                    }
                    EntityType.POWERUP_SHIELD -> {
                        shieldHits = 2
                        soundFX.playNitroSound()
                        objectsToRemove.add(obj.id)
                        updatedMessages.add(FloatingMessage(messageIdCounter++, "SHIELD ACTIVE!", 0xFF00E676, playerY - 0.1f, 1f, 1200L))
                    }
                    EntityType.POWERUP_REPAIR -> {
                        newHealth = (newHealth + 40).coerceAtMost(100)
                        soundFX.playCoinSound()
                        objectsToRemove.add(obj.id)
                        updatedMessages.add(FloatingMessage(messageIdCounter++, "REPAIRED +40 HP", 0xFF00E676, playerY - 0.1f, 1f, 1200L))
                    }
                    EntityType.POWERUP_MAGNET -> {
                        state = state.copy(magnetTimerSeconds = 8f)
                        soundFX.playNitroSound()
                        objectsToRemove.add(obj.id)
                        updatedMessages.add(FloatingMessage(messageIdCounter++, "COIN MAGNET!", 0xFFFFD700, playerY - 0.1f, 1f, 1200L))
                    }
                    EntityType.OIL_SLICK -> {
                        soundFX.playCrashSound()
                        haptics?.triggerCollisionHaptic(isHeavy = false)
                        newCombo = 1
                        spawnSparkleParticles(updatedParticles, newX, playerY, 0xFF555555)
                        updatedMessages.add(FloatingMessage(messageIdCounter++, "SLIPPED!", 0xFFFFB74D, playerY - 0.1f, 1f, 1000L))
                    }
                    EntityType.TRAFFIC_SEDAN, EntityType.TRAFFIC_TRUCK, EntityType.POLICE_CAR, EntityType.ROAD_SPIKE -> {
                        if (shieldHits > 0) {
                            shieldHits -= 1
                            soundFX.playCrashSound()
                            haptics?.triggerCollisionHaptic(isHeavy = false)
                            objectsToRemove.add(obj.id)
                            spawnSparkleParticles(updatedParticles, obj.xNormalized, obj.yNormalized, 0xFF00F0FF)
                            updatedMessages.add(FloatingMessage(messageIdCounter++, "SHIELD ABSORBED!", 0xFF00F0FF, playerY - 0.1f, 1f, 1000L))
                        } else {
                            val damage = if (obj.type == EntityType.TRAFFIC_TRUCK) 45 else 30
                            newHealth -= damage
                            soundFX.playCrashSound()
                            haptics?.triggerCollisionHaptic(isHeavy = (obj.type == EntityType.TRAFFIC_TRUCK || newHealth <= 0))
                            objectsToRemove.add(obj.id)
                            newCombo = 1
                            spawnSparkleParticles(updatedParticles, newX, playerY, 0xFFFF2A55)
                            updatedMessages.add(FloatingMessage(messageIdCounter++, "CRASH -$damage HP", 0xFFFF2A55, playerY - 0.1f, 1f, 1200L))
                        }
                    }
                }
            } else if (obj.yNormalized > playerY && obj.yNormalized < playerY + 0.15f) {
                // Near-miss Close Call check!
                val dx = abs(obj.xNormalized - newX)
                if (dx in 0.19f..0.28f && (obj.type == EntityType.TRAFFIC_SEDAN || obj.type == EntityType.TRAFFIC_TRUCK)) {
                    if (spawnTimerFrames - lastCloseCallFrame > 20) {
                        lastCloseCallFrame = spawnTimerFrames
                        newCloseCalls += 1
                        newCombo = (newCombo + 1).coerceAtMost(5)
                        soundFX.playCloseCallSound()
                        haptics?.triggerCloseCallHaptic()
                        val bonusPts = 150 * newCombo
                        updatedMessages.add(FloatingMessage(messageIdCounter++, "CLOSE CALL! +$bonusPts", 0xFFFFD700, playerY - 0.12f, 1f, 1000L))
                        alertMessage = "CLOSE OVERTAKE x$newCombo!"
                    }
                }
            }

            // Remove out of bounds objects
            if (obj.yNormalized > 1.2f || obj.yNormalized < -0.3f) {
                objectsToRemove.add(obj.id)
            }
        }

        newObjectsList.removeAll { objectsToRemove.contains(it.id) }

        // Update particles
        val particlesIter = updatedParticles.iterator()
        while (particlesIter.hasNext()) {
            val p = particlesIter.next()
            p.ageFrames++
            p.xNorm += p.vx * deltaSeconds
            p.yNorm += p.vy * deltaSeconds
            p.alpha = (1f - (p.ageFrames.toFloat() / p.maxAgeFrames)).coerceAtLeast(0f)
            if (p.ageFrames >= p.maxAgeFrames) {
                particlesIter.remove()
            }
        }

        // Update weather particles
        val updatedWeatherParticles = state.weatherParticles.map { p ->
            when (state.weather) {
                WeatherCondition.NEON_RAIN -> {
                    val speedMult = 1.0f + (newSpeed / 75f)
                    var newY = p.yNorm + p.speedY * deltaSeconds * speedMult
                    var newX = p.xNorm + p.speedX * deltaSeconds
                    if (newY > 1.1f) {
                        newY = -0.15f
                        newX = Random.nextFloat() * 1.2f - 0.1f
                    }
                    p.copy(xNorm = newX, yNorm = newY)
                }
                WeatherCondition.CYBER_SNOW -> {
                    val speedMult = 1.0f + (newSpeed / 120f)
                    var newY = p.yNorm + p.speedY * deltaSeconds * speedMult
                    var newX = p.xNorm + (sin((p.id + spawnTimerFrames * 0.1f)) * 0.08f + p.speedX) * deltaSeconds
                    if (newY > 1.1f) {
                        newY = -0.1f
                        newX = Random.nextFloat() * 1.2f - 0.1f
                    }
                    p.copy(xNorm = newX, yNorm = newY)
                }
                WeatherCondition.CLEAR -> p
            }
        }

        // Update messages
        val msgsIter = updatedMessages.iterator()
        while (msgsIter.hasNext()) {
            val msg = msgsIter.next()
            msg.yNorm -= deltaSeconds * 0.12f
            msg.alpha -= deltaSeconds * 0.8f
            if (msg.alpha <= 0f) {
                msgsIter.remove()
            }
        }

        // Check death
        if (newHealth <= 0) {
            soundFX.playCrashSound()
            return state.copy(
                status = GameStatus.GAME_OVER,
                health = 0,
                speedMph = 0f,
                closeCallAlert = "VEHICLE TOTALED!"
            )
        }

        return state.copy(
            playerXNorm = newX,
            playerLane = lane,
            speedMph = newSpeed,
            rpmRatio = rpm,
            gear = gear,
            health = newHealth,
            nitroLevel = currentNitroLevel,
            isNitroActive = activeNitro,
            hasShield = (shieldHits > 0),
            shieldHitsRemaining = shieldHits,
            score = newScore,
            distanceMeters = newDistance,
            coinsCollected = newCoins,
            closeCalls = newCloseCalls,
            comboMultiplier = newCombo,
            roadOffsetNormalized = scrollOffset,
            magnetTimerSeconds = newMagnetTimer,
            isMagnetActive = magnetActive,
            timeRemainingSeconds = if (state.mode == GameMode.TIME_TRIAL) (state.timeRemainingSeconds + addTimeSeconds) else state.timeRemainingSeconds,
            objects = newObjectsList,
            particles = updatedParticles,
            weatherParticles = updatedWeatherParticles,
            messages = updatedMessages,
            closeCallAlert = alertMessage
        )
    }

    private fun generateInitialWeatherParticles(weather: WeatherCondition): List<WeatherParticle> {
        val list = mutableListOf<WeatherParticle>()
        var id = 1L
        when (weather) {
            WeatherCondition.NEON_RAIN -> {
                for (i in 0..75) {
                    list.add(
                        WeatherParticle(
                            id = id++,
                            xNorm = Random.nextFloat() * 1.2f - 0.1f,
                            yNorm = Random.nextFloat(),
                            speedY = Random.nextFloat() * 1.2f + 1.2f,
                            speedX = -(Random.nextFloat() * 0.15f + 0.10f),
                            length = Random.nextFloat() * 30f + 25f,
                            radius = 1.5f,
                            alpha = Random.nextFloat() * 0.5f + 0.35f,
                            colorHex = 0xFF80D8FF
                        )
                    )
                }
            }
            WeatherCondition.CYBER_SNOW -> {
                for (i in 0..65) {
                    list.add(
                        WeatherParticle(
                            id = id++,
                            xNorm = Random.nextFloat() * 1.2f - 0.1f,
                            yNorm = Random.nextFloat(),
                            speedY = Random.nextFloat() * 0.3f + 0.15f,
                            speedX = Random.nextFloat() * 0.10f - 0.05f,
                            length = 0f,
                            radius = Random.nextFloat() * 4f + 2.5f,
                            alpha = Random.nextFloat() * 0.5f + 0.4f,
                            colorHex = 0xFFE0F7FA
                        )
                    )
                }
            }
            WeatherCondition.CLEAR -> {
                // Clear sky has no heavy weather particles
            }
        }
        return list
    }

    private fun spawnNewObjects(list: MutableList<GameObject>, state: GameEngineState) {
        val laneX = listOf(-0.60f, -0.20f, 0.20f, 0.60f)
        val selectedLane = Random.nextInt(0, 4)
        val posX = laneX[selectedLane]

        val roll = Random.nextInt(0, 100)
        val type = when {
            roll < 45 -> EntityType.TRAFFIC_SEDAN
            roll < 60 -> EntityType.TRAFFIC_TRUCK
            roll < 75 -> EntityType.COIN
            roll < 83 -> if (state.mode == GameMode.POLICE_PURSUIT) EntityType.POLICE_CAR else EntityType.POWERUP_NITRO
            roll < 90 -> EntityType.POWERUP_SHIELD
            roll < 95 -> EntityType.POWERUP_MAGNET
            else -> EntityType.POWERUP_REPAIR
        }

        val color = when (type) {
            EntityType.TRAFFIC_SEDAN -> listOf(0xFF3B82F6, 0xFFEC4899, 0xFF8B5CF6, 0xFF10B981, 0xFFF59E0B).random()
            EntityType.TRAFFIC_TRUCK -> 0xFF64748B
            EntityType.POLICE_CAR -> 0xFF1E293B
            EntityType.ROAD_SPIKE -> 0xFFDC2626
            EntityType.COIN -> 0xFFFFD700
            EntityType.POWERUP_NITRO -> 0xFF00F0FF
            EntityType.POWERUP_SHIELD -> 0xFF00E676
            EntityType.POWERUP_REPAIR -> 0xFF22C55E
            EntityType.POWERUP_MAGNET -> 0xFFA855F7
            EntityType.OIL_SLICK -> 0xFF1E1E1E
        }

        val width = if (type == EntityType.TRAFFIC_TRUCK) 0.22f else if (type == EntityType.COIN) 0.10f else 0.16f
        val height = if (type == EntityType.TRAFFIC_TRUCK) 0.28f else if (type == EntityType.COIN) 0.10f else 0.16f

        list.add(
            GameObject(
                id = objectIdCounter++,
                lane = selectedLane,
                xNormalized = posX,
                yNormalized = -0.2f,
                widthNormalized = width,
                heightNormalized = height,
                type = type,
                speedNormalized = 0.5f,
                colorHex = color
            )
        )
    }

    private fun spawnExhaustParticles(list: MutableList<ParticleFX>, playerX: Float, isNitro: Boolean) {
        val color = if (isNitro) 0xFF00F0FF else 0xFFFF9800
        for (i in 0..2) {
            list.add(
                ParticleFX(
                    id = particleIdCounter++,
                    xNorm = playerX + (Random.nextFloat() * 0.08f - 0.04f),
                    yNorm = 0.88f,
                    vx = Random.nextFloat() * 0.1f - 0.05f,
                    vy = Random.nextFloat() * 0.3f + 0.2f,
                    radius = Random.nextFloat() * 8f + 4f,
                    alpha = 0.8f,
                    colorHex = color,
                    maxAgeFrames = 15
                )
            )
        }
    }

    private fun spawnSparkleParticles(list: MutableList<ParticleFX>, x: Float, y: Float, color: Long) {
        for (i in 0..12) {
            val angle = Random.nextFloat() * Math.PI.toFloat() * 2f
            val speed = Random.nextFloat() * 0.4f + 0.1f
            list.add(
                ParticleFX(
                    id = particleIdCounter++,
                    xNorm = x,
                    yNorm = y,
                    vx = kotlin.math.cos(angle) * speed,
                    vy = sin(angle) * speed,
                    radius = Random.nextFloat() * 10f + 5f,
                    alpha = 1.0f,
                    colorHex = color,
                    maxAgeFrames = 25
                )
            )
        }
    }
}
